# Roshan ballet and magician object acting

Source-only native Canvas prototype, commissioned 2026-10-31. Production gameplay,
character assets, saves, demo build, dev and master are unchanged. Related
MA-ROSHAN-005/006 stay CONFIRMED_OPEN; this package closes neither finding.

## Run and inspect

Open `demo/project.godot` with exactly Godot 4.7.2-stable, Mobile renderer.
Keys 1/2 select ribbon or magician, 3/4/5 play the inherited arm/blink/tail motions,
Space pauses, arrows step one 30-fps frame. Performances hold their endpoints;
replay explicitly resets the presentation-only illusion. No saves or rewards exist.

The costume skin ID `ballet` maps to active runtime career ID `ballerina`.
The wand and illusion art are existing Magician runtime props. The ribbon is a
local Canvas flexible strand informed by the ballet specialist's painted current.
The source underwater neutral pose uses buoyancy; this is not new land walking.

## Pinned inputs and limits

`baseline/frozen_inputs_v8.json` identifies the corrected full-garment candidate.
The local source bytes were verified before copying; 26bd6d1f is a rejected overlay
predecessor and supplies no corrected garment authority. `evidence/source_inventory.json`
lists source hashes, provenance and approval scope. Native new grip take 01 stays
in `native/`; its local Aseprite repair is separate from all protected originals.
One built-in ImageGen call supplies the named closed-hand gap, with no paid API
job and no generated animation-frame campaign. Model revision/seed/billing are
not exposed by the built-in tool. Garments are reused unchanged.

`contract/rig_v1.json` is a local frozen copy of roshan.canvas.shared 1.0.0;
its SHA-256 is recorded in the inventory. The shared-contract chat alone owns
bone/rest/view/socket migration. This study changes no topology, rest or common
vertex weights. It preserves all original arm_bend, blink and tail_bend curves.

The v1 contract supplies front-view sockets, but no completed common waist
ownership adapter. Known mixed-body/tail gaps remain fail-closed. All 27 seed
slot combinations need actual outline coverage; deterministic swaps alone cannot
establish fit. Corrected seed/shared immutable publication must be verified before
a downstream compatibility-complete handoff can be claimed.

## Actions and attachment

The ballet phrase raises a held baton, sweeps a curved ribbon in the picture
plane, then settles. A true body twirl and port-de-bras extremes remain source
gaps requiring shared action/view adapters and authored changing surfaces.
The magician raises a held wand, aligns its pearl with the stationary hat opening, then makes the
existing lamb illusion disappear. The lamb fades only after that aim alignment; the vanished
state holds instead of restarting automatically. This presents the current game
VANISH verb; the rope states are inventoried but this study claims no rope pull.

The fixed prop orientation follows the hand rest-relative rotation; the small aiming beat is authored on the wrist. Rejected center-only attachment r1 and its native sources/masters stay in `rejects/attachment_v1/`.

The held pearl wand uses grip.screen_left (LeftHand local [24,0]) at native
1024-square units. Its own shaft grip [141,379] and pearl tip [390,95] use uniform
0.52 scale, rigid in-plane rotation, no affine perspective stretch. Prop shaft is
behind the fingers; its circular section retains this front-view applicability.
The open hand is used for all seed regressions. The authored closed hand is used
only for held actions. No pickup/release is claimed. Hat/lamb are separate illusion
objects behind the held wand. Opening alignment interval is 2.8–3.0 seconds; the fixture is
fixed from the planned native tip at that pose, and fade begins at 2.8 seconds.

## Evidence lanes

Actual Godot Vulkan Mobile captures and telemetry, original strict geometry/motion
floors, per-mix alpha components/waist gaps, source-poison and reinsertion controls,
grip/support/aim alignment, transitions and endpoint evidence are recorded in `evidence/`.
Review movies/chronological boards and editable Aseprite sources live separately.
Machine evidence never establishes natural acting or exact human acceptance.

Agent visual review, full-speed human review, target-device performance/playback,
child comprehension, owner identity/style/action acceptance and production adoption
remain separate. This package is a review candidate, not DELIVERY_ACCEPTED.

## Reproduce

Run `tools/package_and_audit.py` after native captures; the script preserves
same-threshold failing controls and emits the source/evidence manifest.
`tools/run_project_gate.py` runs the canonical full project gate using a byte-equal
LF helper only for Windows shell portability. Its receipt records exact source
and engine hashes. Audit impact: `design/audit_impacts/roshan-job-rig-performance-20261101.json`.

Exact executed files are preserved in `evidence/executed_source_v3.zip`; a scoped `.gitattributes` rule also preserves literal package bytes across GitHub and operating systems.

The current V3 controller keeps the exact supported original whole-body entry/hold/return path while easing the new arm phrase. Rejected independent tool rotation and timing/tail studies remain separate. The neutral-reference and head-motion hypotheses were tested and disproved; no head registration or body-lean trial is part of the current controller.

Restore exact native frames with `tools/unpack_frames.py --version final_v3`; every original PNG/JSON byte is retained through `evidence/capture_store_index.json` and its verified archives. Other versions remain explicitly diagnostic/rejected. Full project evidence preserves the failed whole-script attempts, the passed canonical prefix and the literal repaired-coverage suffix; no failed whole-script exit is relabelled green.

Current source evidence: all9 inherited-motion regressions, both211-frame new actions, all4 mesh groups over5 clips,422 editable-master frame round trips,243 original fresh-instance comparisons/19,248swaps and44 new-transition comparisons/3,496mixed-rate samples pass. Positive source sequences retain zero grip holes and zero outline-failed frames. Injected grip-hole/tear/detachment/scale/old-clothes/relative-rotation faults fail their own controls as expected. All27 mix combinations were also sampled at8poses:72 of216 snapshots still fail the existing mixed-waist fit. This is a compatibility blocker, not a hidden exception.

## Publication state

The candidate is a locally staged source review packet. Publication is blocked pending an explicit owner exception to AGENTS.md's all-green-before-commit rule. Three approved4.7.2 full-game import attempts exited nonzero; the two verbose native/console attempts recorded0xffffffff with no logged script/resource error. They are not timeout passes. The production tree remains byte-identical to frozenf59a1d1d, whose exact GitHub probe run41273494099 is green. Source checks remain separate and pass. Long canonical audio/static and independent2D/probe checks are separate addenda; pending work is not relabelled successful. PUBLICATION.json records the limited exception request. No local directory or staged manifest is a delivered GitHub handoff.
