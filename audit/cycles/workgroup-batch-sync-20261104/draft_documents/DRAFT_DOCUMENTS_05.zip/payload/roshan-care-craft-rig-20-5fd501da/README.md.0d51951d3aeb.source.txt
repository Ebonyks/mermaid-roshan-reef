# Care and craft native rig source study — 2026-11-01

**SOURCE PROTOTYPE — NOT ACCEPTED.** Isolated Candy Maker / Nursery Nurse work under the demo freeze. Production game, voices, saves and protected source artwork are unchanged.

Authoring is closed: six built-in ImageGen calls including rejects, no paid API jobs. Final action capture finished within the 180-minute production limit. Exact active cleanup minutes were not instrumented and are not invented. Verification and export of the frozen work continue separately.

## Run and scope

Open demo/project.godot with exact Godot **4.7.2-stable**, open **job_mesh.tscn**, and run that scene. The earlier job.tscn preserves the rejected rigid-part method. These are adult review tools.

Keys 1/2 choose Candy Maker/Nursery; 3/4/5 choose the original arm bend, blink and tail bend. Space pauses; arrows step at 30 Hz. Five stable outfit families remain available for baseline slot tests. Job acting selects complete themed sets; mixed-slot job acting is not signed off.

Candy handling lasts eight seconds: original closed mitten/tongs, unchanged flower candy and fixed original pan. The neutral working wrist drives the actual tong-mouth point [45,109]; the other hand supports the candy underside. Grasp 1.8s, lift complete 3s, hold ends 4.9s, return 6s, release 6.2s, rest 8s.

Nursery enters and exits already carrying the unchanged baby. Both hands remain active at its base and upper back during the gentle lift/lower. Pickup, crib placement and release are outside this loop. The crib is an inventoried reference. Baby PNG bytes are unchanged; runtime scaling is uniform.

## Architecture and open defects

Fourteen Bone2D IDs/rest transforms, original three curves and common-vertex weights remain unchanged. Contract v1.0.0 is pinned in contract/rig_v1.json. Only the shared-contract chat owns topology/rest and the common waist convention.

Complete RGBA garments retain their own contours. Original clothing is physically erased from the anatomy input. Final acting reuses rounded painted arm sources, masks old hand/right-arm pixels before new garment compositing, and binds grip views separately. Cut-off rigid elbows, duplicated baked hands, premature wrist clipping and the wrong-tail generation remain rejected evidence.

The waist material patch remains visibly unaccepted. Shoulder/cuff/neckline/waist/fin continuity, hand anatomy, perspective, transitions and full-speed review remain blocking. Contact distances and smoothness do not accept the pixels. Front only; unprovided views fail closed. No 3D assets or on-device inference were added.

## Evidence

STATUS.json and evidence/final_source_verification.json are result entry points. Read process exits and individual check JSON separately.

- final_frames: earlier full rigid-part capture, rejected visually.
- mesh_frames: rounded-mesh trial, including all three original action regressions.
- final_job_frames: final wrist-bound actions, character-only outlines, actual faults, mixed pictures and seek telemetry.
- Twelve independent original-restoration cases, 1,125 fresh-instance wardrobe comparisons and 19,248 live swaps pass. Equality does not establish garment fit.
- replacement_baselines/replacement_audit.json passes 582 original-three-action frames, source poison and actual old-clothing reinsertion controls. The unsupported prior checker invocation is retained. This baseline checker does not accept final-job derivation.
- The earlier 375-state snapshot had 45 disconnected states; the final action-aware scene has 200 disconnected mixed states. Failed outline/contact details remain available; no compatibility signoff follows.
- Composed-template geometry diagnostics are separate from actual-shader-surface checks. Floors remain stretch 0.8–1.2, zero visible inversions, rigid head, original seam allowance, 140 degrees/s and 650 degrees/s².
- Layered Aseprite sources are in masters. Earlier native loop imports carry review/rejected tags and exact round-trip reports. GDScript remains the editable bone/timing source. Earlier flattened masters are not the latest render method.
- Review movies use actual native frames at their original 30 Hz timestamps, whole-canvas fit to 1280×720, no interpolation. They are not accepted cinematics or device-performance evidence.
- Delivery archive entries have explicit hashes. Raw build/review directories are staging, never a delivered external handoff.

## Acceptance and publication

MA-ROSHAN-005/006 remain open. Shared waist compatibility, corrected immutable v8 seed publication, exact human full-speed/frame-step review, target device, child and owner acceptance remain separate.

All original project gate attempts and retries are retained. Stuffie/geologist focused retries passed; story clips/chapter two and adapter timeouts require final results. The literal-$GODOT Windows adapter error is separate from the successful corrected engine check.

No dev/master integration or release is authorized. ARCHIVE_COMPLETE, GENERATION_READY and DELIVERY_ACCEPTED are separate. An unpublished local packet is HANDOFF_BLOCKED. No red gate is silently waived.

Exact sources/hashes, six prompts/operation IDs, attempts, fitting and caps are in source_inventory.json, imagegen_records.json, provenance.json, fitting.json and job_cards.json.

The oversized native loop masters are stored losslessly as XZ files under archives. evidence/editable_master_archives.json maps each stored payload to its restored masters filename and exact original SHA-256. The local native originals remain untouched; decompressing an XZ restores the original editable Aseprite bytes.
