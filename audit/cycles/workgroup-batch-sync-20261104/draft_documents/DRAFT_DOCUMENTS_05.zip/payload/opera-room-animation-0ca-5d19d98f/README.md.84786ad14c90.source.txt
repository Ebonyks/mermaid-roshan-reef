# Opera foyer object-animation candidates

Owner commission: 2026-10-31. Source commit: `36b58801b1a9a4b7edc76b8c3bb72091565590cb`.
Status: **SOURCE_ANIMATION_CANDIDATE**. No production script, scene, save, protected art or shipped asset changes.

Open `index.html` in a browser, or serve this directory locally. [Full-color overview](exports/foyer_review.mp4) is the preferred four-second full-color overview of the three responses in sequence. It is a source review, not cinematic or runtime delivery. The 3.93-second GIF overview is retained as a palette-limited reference with visible banding. Tap the left chandelier, its adjacent upper-gallery candle, or the central planter. The three cards also play each response. Pause, frame-step, repeat, and return to rest are available. The preview replaces pixels on one flattened Canvas; it is not a Godot/runtime or device capture.

| Item | Short response | Fixed structure | Priority and scope |
|---|---|---|---|
| [Left chandelier](exports/chandelier.gif) | A restrained warm-light cascade through painted crystals; 12 states, 1.31 seconds | Ceiling mount, chain, crystal contours and wall | Strong fit for an optional discovery tap. Companion/right chandelier needs its own exact source registration before reuse. |
| [Upper-gallery candle](exports/sconce.gif) | Painted candle light dips, warms and returns; 12 states, 1.31 seconds | Brass fixture and surrounding wall | Small supporting response. At phone scale its discoverability still needs testing. No detached sparkle or room-wide wash. |
| [Central shell planter](exports/planter.gif) | Existing fronds bend left/right and settle; 12 states, 1.31 seconds | Root, shell bowl, gold rim and upholstered seat | Strong fit for a reachable optional discovery tap. Uses one narrowly masked carpet clean-plate repair. |
| Tea/drink trolley | Deferred: a pour or service response would suit the room | Wheels, tray and table | Existing painting has no approved pouring, vessel-interior or hand-contact sequence. No invented action or new character. |
| Lounge cushions and side planters | Future candidates: cushion compression or separately registered leaf rustles | Source furniture supports | Need their own contact/ownership states and clean underlays; central planter is the bounded pilot. |
| Curtains, doors, lifts | No new candidate | Existing routing/fixtures | Preserve navigation ownership and the demo-disabled left playtest menu; older Opera Hall curtains belong to different art. |

## Reuse and derivation

The current three-floor foyer painting is the identity/layout authority: `assets/flats/castle/opera_house_venue_2d/room_opera_house_venue.png`, SHA-256 `4378b9eb65d7d009afc3dbbe4c92f45bbbb57e273f9ef762dd0c9f66e7029dd0`. Existing Opera Hall v2/v4 chandelier, curtain, footlight, stage-star and sconce sheets were inventoried; they depict a different room and were not substituted.

Native Aseprite 1.3.18.4 authors all complete frames in one layer per master. `author.lua` is the deterministic recipe. `build_records.py` uses Pillow only for reading/verification and JSON provenance; Aseprite writes the raster derivatives. The planter uses the original painted foliage, one generated clean-carpet reference and declared spatial bilinear sampling. No generated animation frames, temporal interpolation, paid external jobs, guide pixels, body-part animation or new scene. One built-in ImageGen call; its hidden model revision and unexposed usage/cost remain explicit in `manifest.json`. Only the bounded foliage-background mask retains generated pixels; the rest of the generated crop is excluded.

The atlas exports are complete **opaque source-registered replacement patches**, with transparent unused cell padding. They are not isolated RGBA props and do not establish runtime compliance with `DL-LAY-03`, `DL-LAY-05` or `DL-LAY-08`. Production needs tight whole-object cutouts, clean complete baked footprints, and verified occlusion with Roshan. Future integration must either replace the owned base pixels or use a verified underlay/card pairing; it must not stack an extra visible fixture, expose a fill hole, stretch these patches, or reuse a left-fixture background at a different location. GIF previews loop for inspection and use a reduced palette; the PNGs and native masters are authoritative.

## Evidence and remaining gates

Applicable rules, risks, source hashes, caps and required evidence were recorded before production in `PLAN.json`. Each `*_job.json` follows the canonical animation job-card fields. `manifest.json` binds sources, method, clean-plate attempt and output hashes. `verification/pixel_checks.json` checks 36 reopened-master exports, atlas equality, source-equal first/end states, fixed supports, bounds, opacity and transparent padding. These checks establish source packaging only.

The first source hold is 30ms so the preview begins its visible change within two frames at a 30fps target. The final 360ms hold intentionally returns the room to rest. Nothing plays or awards progress passively; the browser has no rewards or save writes. Repeated taps restart only the chosen response; leaving the tab cancels it.

Local agent normal-speed/frame-step review, actual Godot sampling and production input/lifecycle/save checks, room/HUD captures at supported aspects, exact Mobile/Speedy device performance, child discovery/readability, sound and owner identity/style/motion acceptance are separate lanes. See `verification/review.json` and the linked impact for actual results; missing evidence remains pending. No finding lifecycle or whole-game audit satisfaction changes. `ARCHIVE_COMPLETE`, generation applicability, runtime integration and `DELIVERY_ACCEPTED` are reported independently; this is not a cinematic/external-generator handoff.

Impact: `design/audit_impacts/opera-foyer-objects-20261031.json`.

Rebuild from the repository root with native Aseprite `-b --script` for `author.lua`, `verify_master.lua` and `compose_review.lua` in this folder; then run `python -B assets_src/animation/opera_foyer_objects_20261031/encode_review.py` and `build_records.py`. The encoder uses the installed FFmpeg 8.1.2; `verification/video_review.json` records source hashes, all native/output frame mappings, 30fps cadence quantization and whole-canvas 1.25x scaling. No temporal interpolation, new artwork or sound is added. Exact full-color PNGs and the three editable action masters remain authoritative.

Integration recheck: `f59a1d1d5bdd58604f4706d16fb4e76d8f7db8b9` preserves the exact source painting. `ODR-DEMO-FREEZE-20261031` keeps this source review on its topic branch, outside `dev` and the demo. The original incomplete/red validation and unchanged-assertion diagnostic are preserved in `verification/prior_validation.json`; the fresh full-suite result is recorded separately.

Editable action masters: [chandelier](masters/chandelier.aseprite), [candle](masters/sconce.aseprite), [planter](masters/planter.aseprite). Open the [interactive source review](index.html) locally with its adjacent files.

Validation blockers: the original full runs and82-command baseline retain Geologist separation and child-process deadline failures. A minimal Geologist motion-handoff trial passed the unchanged Opera2D oracle; its patch is archived in `verification/geologist_motion_handoff_candidate.patch`, not applied to this source-only branch. The separate ChapterTwo startup hypothesis remains an unimplemented archived proposal: the instrumented child could finish all checks but miss process exit. No deadline, predicate or release gate was relaxed. Full project validation is not green and publication remains blocked by the before-commit rule.
