# Doctor and teacher native garment prototype

Source-only commission from the Roshan rigging study, 2026-10-31 (Los Angeles).
No production character, game, save, voices or release integration. The approved
feedback on basic motions does not accept these outfits or close
`MA-ROSHAN-005` / `MA-ROSHAN-006`.

Open `godot/project.godot` with exactly Godot 4.7.2-stable, Mobile. Run
`godot/live.tscn` for the object demo; `study.tscn` has the original three curves.
Keys: D doctor, T teacher, O original; H/J/K independent head/body/tail; 1–3
original motions, 4 job action, R restart, Space pause. Teacher placement is
one-shot: the shape stays at the matching slot after release until restart.

The single shared 14-Bone2D rest and original curves are retained. Garments are
new RGBA cutouts with separate sleeves and authentic new contours. The old
blouse, ruffles and tail clothing are removed from the anatomy base; originals
remain available for exact restoration. Generated face, hair, hands and fins
are excluded; the shared original identity remains the anatomy authority.

`plan.json` records scope, rules, named gaps, limits and outstanding acceptance.
`sources.json`, `fitting.json`, `contract/` and `jobs/` record derivation and
bindings. `seed/` contains the frozen provisional v8 inputs needed by this
standalone source demo. The owner-rejected overlay predecessor `26bd6d1f` is
excluded as a garment implementation. Corrected upstream and shared-contract
immutable publication are required before a downstream handoff is complete.

Doctor uses the real CAST/BANDAGE roll and patient. Teacher uses the real MATCH
circle and slot. Both are front-view studies. Neither stretches a front prop
to impersonate a view turn. Additional perspective and closed-grip acting need
their own authored sources and review before extending these actions.

Captures are actual desktop Mobile frames. Numerical geometry/contact checks,
agent visual review, owner art/motion acceptance and device/child acceptance are
separate claims. Inspect `evidence/` and `review/` for the exact candidate;
unfinished or failed checks remain explicit. Runtime integration and master
audit satisfaction are not claimed. Archive/publication receipts live with the
versioned manifest when publication succeeds.

To reproduce parts from the frozen local inputs, run `build_parts.py`, then
`final_fit.py`, then `repair_join.py`, then `clean_tail.py`, then `waist_binding.py`, then `setup_demo.py` with Python, Pillow, NumPy and SciPy.
These scripts prefer the included native/seed files; workstation source paths
record the bootstrap lineage only. This deterministic sequence includes the
waist bridge and identity exclusions and uses no generation service.
Run the approved engine with `--path godot --script capture.gd -- OUTPUT doctor`
and repeat with `teacher`; OUTPUT is a new review directory. `analyze.py`
expects `evidence/raw/{doctor,teacher}_v9` and retains the fixed seed floors.
`masters.lua` imports exact captured frames with Aseprite; the garment masters
have separate RGBA layers, while review animation masters preserve whole frames.

## Native source review

[Doctor job movie](review/doctor_job.mp4) · [Teacher job movie](review/teacher_job.mp4). These are source studies, with owner/device/child acceptance pending.

![Doctor native job contact board](review/doctor_job_board.jpg)

![Teacher native job contact board](review/teacher_job_board.jpg)

The final v9 binding shares existing tail weights for painted waist overlap and returns wide garment edges to Torso over 60px outside tail alpha. The original 0.8-1.2 stretch floors are unchanged. A v8 over-stretch rejection remains in evidence. Art stopped at 147.053 of 150 elapsed preparation minutes, using 3 of 4 aggregate generation calls; verification/export does not reset that cap. Any source edit invalidates its affected captures, mixtures, correspondence and master evidence.

Dense triangle interpolation also passes the same 1px waist limit (doctor 0px; teacher 0.0144px across 1,237/1,288 same-painted texels and 412 poses each). The selected teacher tail pose shows a visible painted join below the vest; this remains a visual review item.

After `masters.lua`, run `version_master_metadata.lua`, then `reopen_parts.lua` and `verify_masters.py`. This native Aseprite save adds descriptive capture-version labels and normalizes editable-file metadata. A little-endian file-size byte in the initial teacher blink master accidentally resembled a JSON opener to the unchanged model scanner. Original intermediate bytes are retained locally; all final decoded frames/layers must still match exactly. See `evidence/master_serialization.json`.

Corrected parent source is pinned at `4c19341b6c0f9650cfba51dfc661f95b258ac434`: anonymous exact-byte checks pass for all 36 frozen/used source files, including the 15 inputs copied here. See `evidence/upstream_parent_receipt.json`. This does not accept the parent mixed-slot fit failures. Shared contract 1.0.0 remains a local frozen copy awaiting its owner-workstream publication; downstream completion remains blocked on that pin.

Publication gate: the completed canonical sequence records 81/82 trusted probes passing. `probe_opera_2d` fails the existing Geologist finale-partner clearance check. Production scripts, scenes, project settings and assets are unchanged from the recorded baseline. The all-OK-before-commit rule blocks publication without an explicit owner exception for a source-only review packet; no game repair or release is authorized by this task.

The isolated canonical `probe_opera_2d` retry reproduces the same Geologist clearance failure; see `evidence/opera2d_retry_receipt.json`. No game or probe repair was made under this source-only commission.
