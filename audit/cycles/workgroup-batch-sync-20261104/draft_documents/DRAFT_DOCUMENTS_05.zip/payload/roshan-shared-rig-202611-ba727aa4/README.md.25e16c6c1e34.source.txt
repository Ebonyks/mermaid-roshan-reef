# Roshan shared Canvas rig and outline protocol — v1

Status: **SOURCE-ONLY PROTOTYPE**, under the demo freeze. No production character,
scene, save, career mechanic, dev/master integration or release is authorized.
The owner's positive feedback concerns the basic motions, not final character,
visual, device, child, owner or master-audit acceptance.

The first frozen shared contract is [rig_v1.json](contract/rig_v1.json), with its
literal SHA-256 in [FREEZE.json](contract/FREEZE.json). Outfit work binds to this
version and hash. Fourteen existing Bone2D names/rest transforms, original mesh
vertices/weights, and `arm_bend`, `blink`, `tail_bend` curves remain intact.
The semantic ID adapter and compatibility checks are in
[validate_contract.py](tools/validate_contract.py); the example two-hand tray
binding and its schema are in `contract/`. Unavailable views fail closed.
The seed's screen-side names are source labels, not a claim about anatomical
left/right. Do not rename or swap them implicitly when facing changes.

## What to run

Open `demo/project.godot` with the resolver-approved **Godot 4.7.2-stable**.
It is an independent Mobile/Canvas2D project. Keys 1–3 select carry, low/high
pickup/place and authored-view turn; 4–6 select the original motions. Space
pauses, arrow keys frame-step and R compares unrepaired/repaired binding.
No production script or save is loaded. Captures use `demo/capture.gd` and
an actual transparent SubViewport; the engine receipt identifies the GPU,
renderer and build. The root `.gdignore` excludes the whole prototype from the
game's importer/export. Generated native art is preserved separately from its
1024-square source-demo exports.

`contract/action_matrix.json` records 21 action families traced to actual career
surfaces, Day One jobs, Fashion Designer and the Roshan movement profile.
Three seed motions do not cover pointing, waving, grasping, tools, supported
performance, propulsion or a natural turn. Each row records its real source gap.
The tray is the existing painted mint geologist specimen tray, not a placeholder.
Grip/support positions, orientation, draw ownership and contact/release spans are
explicit in the binding. Do not stretch its front surface into a profile.

## Outline analysis and repair loop

1. Freeze the contract, skin/view/object inputs, source hashes and action card.
   Record pose, actual object ownership, expected visible topology, camera,
   support, sockets, contact intervals and allowed view changes. Costume alpha
   belongs to the new garment. Old sleeves, blouse and tail clothing must be
   removed from anatomy in replaced slots; the old outfit alpha is never a
   silhouette constraint for a new outfit.
2. Capture actual Godot frames at normal cadence and record all bone matrices,
   view IDs, sockets, grip errors, underlay state and object ownership. Keep a
   chronological contact sheet, full-speed movie and frame-step sequence.
   Telemetry alone cannot establish that the pictured fingers touch the object.
3. Inspect alpha components/holes/boundary contact, joint alpha coverage,
   frame-to-frame contour differences, known ownership/occlusion, face/hand
   proportions, affine scale, visible triangle strain/flips and entry/exit/seams.
   Preserve the seed's exact .80–1.20 strain, zero flip, 140 deg/s and 650 deg/s²
   floors in its supported three clips. Do not silently apply static topology
   expectations across an authored eye/arm occlusion change. Such changes need
   a named view contract and exact image review; unknown changes stay open.
4. Diagnose a source, weight, part, pose, contact or view error. Repair the smallest
   coherent unit non-destructively. Here the initial whole-body high reach tears;
   optional action-specific Aseprite part bindings test separation on the same
   unchanged skeleton. The original skinned meshes/weights remain available and
   untouched. New action parts are not a replacement of the seed or production
   skin. Their shoulders, sleeve seams, elbows and palm contours still require
   actual review and may fail even with zero socket error.
5. Rerun the *identical* failing pose and every affected transition, mixed slot,
   supported seed clip and loop. Retain the before/after images and diagnostic
   results. Do not reduce a motion, hide a failed frame, reset a budget, widen a
   tolerance or accept an old rejected overlay to obtain a pass.
6. Prove each checker can fail: render tearing, a detached hand, original underlay,
   grip slip and identity distortion; retain an actual authored-view pop and a
   deliberately injected pop. A control passes only when the same sensor rejects
   it. A detected baseline fault is useful evidence, not accepted animation.
7. Review full-speed and frame-step at the exact hashes. Source editability,
   pixel/geometry, natural acting, phone performance, child/owner review and
   production integration are independent claims. Missing human review stays
   missing; do not invent scores. This is not cinematic delivery footage and
   cannot claim a production-profile cinematic pass.

## Authorship, compatibility and limits

One contract owner controls topology/rest and semantic IDs. Outfit workers own
separate skin/object namespaces. Add optional sockets/views in a minor version;
rest/topology/semantic changes need a major version, explicit migration and all
old/new regression evidence. Missing view art blocks that view, not publication
of the review packet. The generated fully clothed turnaround contains changed
surfaces and a baked supported tray; it remains a source study, cannot replace
the seed face, cannot be used as independent prop motion and is not a natural
animated turn by itself. Perspective switching, matte quality, proportions and
entry/exit are separately tested and reviewed.

The read-only replacement-v6 directory supplied **render_v8**, identified by its
frozen-input manifest, not the rejected overlay at `26bd6d1f`. Seed publication
was provisional at task start. A corrected immutable remote seed and matching
bytes must be verified before downstream handoff completion. Never use the
rejected overlay merely because it already has a public commit.

See `jobs/production.json` for the 240-minute task wall window, 75-minute cleanup
ceiling, four-call aggregate cap, two takes per brief and zero external paid
spend. Attempt 1 was blocked by the image tool and produced no output; attempt 2
created the fully clothed view study. Provider revision, seed and billing were
not exposed. No per-frame campaign was performed. Native outputs, Aseprite
masters, exact source cutouts, rejects, telemetry and review evidence remain
separate. All source art retains its original acceptance scope and provenance.

## Audit guidance and evidence

Apply `DL-AUTH-05`–`07`, true Canvas2D rules, `DL-VIS-02`/`06`, `DL-MOT-01`,
`03`, `07`, `10`–`16`, asset provenance and Mobile/performance rules. The canonical
[master planning entry](../../../audit/MASTER_AUDIT_2026-08-09.md#0-planning-entry),
[design language](../../../design/06_COMPREHENSIVE_DESIGN_LANGUAGE.md),
[ledger](../../../design/05_DOC_LEDGER.md), [movement profile](../../../design/animation/ROSHAN_MOVEMENT_LANGUAGE.md)
and [production protocol](../../../design/animation/ANIMATION_PRODUCTION_PROTOCOL.md)
retain authority. `MA-ROSHAN-005` and `MA-ROSHAN-006` remain CONFIRMED_OPEN:
this source experiment repairs no production frame or runtime playback. Green
checks never establish master-audit satisfaction. The whole game remains
UNSATISFIED. Exact commands, results, hashes and remaining acceptance are recorded
in the linked [impact](../../../design/audit_impacts/roshan-shared-rig-20261101.json)
and the versioned `evidence/` receipts. Publication is on an isolated codex branch
only; no dev/master integration is permitted.

## Current v1 contract / controller-v2 result

The contract remains **1.0.0**, literal SHA-256
`b2a5dfe936d13ccdeb88e5c29ad268b19488de7cbe49d9b06abf84a94135fb5f`.
Controller v2 preserves the full high-reach height and fixed lengths, adding a
24-source-pixel lateral arc around the arm's minimum-reach disks. In the exact
954-frame Mobile capture, maximum held socket error is **0.560014 source px**;
maximum support-height error is **0.000024 source px**. All 23,697 mixed-rate
seeks return with zero matrix error and zero ownership leakage. These are
machine contact/state results, not pictured finger-grip or natural acting approval.

The three supported seed motions retain their original geometry/motion floors.
The 27 original/ballet/magician slot mixes pass 243 fresh-vs-live RGBA comparisons
and 19,248 swaps with zero matrix drift. The complete old-clothing/source-poison
survey and its retained controls are reported separately from the 12-case
precheck; never substitute that precheck for full frozen-frame reproduction.
Raw new right-side joint-occupancy probes also expose the seed wrist pivot's
edge placement; their failures remain diagnostic and do not silently rewrite
the supported seed's left-joint acceptance floors.

**Visual result: not ready for final character use.** High-reach sleeves/elbows
and open palms need authored caps/grip views and contour cleanup; the raised
tray obscures too much of the face. The three authored facing drawings show
changing surfaces but still pop between views and retain generated matte,
proportion and tail-view questions. The exact static observations and hashes
are in `evidence/visual_review.json`. Normal-speed and frame-step human review,
phone/child/owner acceptance and production integration remain separate.

The lossless PNG archives in `review/frame_archives/` own the actual captured
pixels; `review/*.mp4` are lossy inspection composites only. Rejected
controller-v1 media/native archives live under `review/rejected_controller_v1/`;
`evidence/controller_v1/relocation.json` resolves their original historical paths.
The layered Aseprite source master and 18 inspection keys reopen with exact RGBA
pixels. Their one-second key holds are for inspection, not the native animation's
timing; the editable Godot controller owns that timing.

## Shared waist trial and current delivery gate

The inherited mixed-slot continuity test fails **27 of81** snapshots even though
fresh/live rendering parity is exact. An optional attachment under `waist/`
uses the existing `waist` semantic anchor, with no rest, topology or common-weight
change. The v4 adapter follows the Body mesh skin field rather than parenting a
rigid patch to Root. Repeated source-row material closes all81 snapshot outlines but is
visually rejected for corrugation. Two targeted painted repairs use the last
two calls of the four-call aggregate budget. The original-body painted patch
accidentally includes a second belt and leaves6 snapshot failures; its bounded
blue-material cleanup remains a visible artificial band and leaves9 snapshot
failures. These are retained source trials, **not a wardrobe-compatibility or
art acceptance claim**. The ballet painted underlap remains a separate candidate.
Dense per-frame seam/endpoint measurements and exact native archives are under
`waist/evidence/`. Do not select a candidate on connectivity alone or lower the
original one-component, clipping, hole, mesh or motion floors.

Generation is stopped at4 aggregate built-in calls (3 native outputs and1
blocked/no-output call). Separate manual cleanup minutes were not instrumented;
no process-budget compliance claim is made. Finish verification/publication of
these bounded trials; further character art needs a new authorized task budget.

The full game regression is separately recorded in `evidence/runtime_gate.json`.
All402 production script/scene/project files and the production Git diff remain
unchanged. Original failures and fresh focused reruns are retained, including
any unresolved baseline failures. The global required pre-commit gate is not
silently waived for a source-only prototype. Publication/remote verification and
the corrected immutable upstream seed remain separate delivery requirements.
No local folder, staged index, unpublished branch or successful source test is
a completed GitHub handoff.

## Weighted waist v4 and final source-review limits

The v4 adapter duplicates the existing Body polygon/UV/triangles/bone paths and
weights verbatim, sharing the existing Skeleton2D. It changes only the optional
underlap texture/material/layer, not the original body or fourteen-bone rest.
All81 head/body/tail snapshots now pass the original numerical seam floors;
nonjoined combinations remain exact. All873 frames for the three affected
body/tail pairs with the original head remain one connected figure with zero
edge clipping and exact loop endpoints. This is **not a full transition pass**.

The first dense check wrongly compared all frames with an unrelated t=1.5
snapshot, producing182 failures. Its report and native pixels remain intact.
The corrected check captures each unchanged garment combination at rest with
the cap disabled, matching the original seed check’s rest-reference method.
The same eight-pixel hole allowance and significant-component rules pass870
of873 frames; three Original/Magician frames still exceed the hole floor.
See `waist/evidence/dense_v4_rest_reference_audit.json`. No tolerance is raised.
The original painted cap still repeats a belt, the v3 material band remains
rejected, and the ballet cap is unreviewed candidate art. No wardrobe-wide,
natural-motion or painted-cloth acceptance follows from these measurements.

Publication is **HANDOFF_BLOCKED**, not delivered. The unchanged baseline still
fails the geologist partner-clearance assertion and Chapter2’s milestone child
wall deadline in repeated fresh runs. The audio-quality audit and visual-design contract suite exceeded the
local runner’s1200-second ceilings. Original logs and later passes are retained;
none of those failures is waived. The corrected parent v8 seed is still local:
its published branch remains the owner-rejected predecessor26bd6d1. No commit,
push, dev/master merge or final acceptance is claimed. `PUBLICATION.json`,
`REMOTE_VERIFICATION.json` and `evidence/DELIVERY_STATUS.json` record the block.

The underlap’s newly visible triangles are also checked explicitly, rather than
borrowing the old body texture’s visibility mask. Across873 native samples,
visible stretch stays0.937839–1.091696 (original bounds0.8–1.2), with zero
inverted visible triangles and the unchanged bone-scale floor. This geometry
pass does not override the three retained hole failures or painted-material
rejections. Document authority and exact changed-file coverage both pass at
the recorded f59a1d1 baseline; those structural checks do not waive full-game
validation or establish any creative acceptance.

The final existing static command inventory records56 attempts. Two commands
remain timed out locally: the complete audio-quality audit and visual-design
contract suite. The original75-test 2D audit retry, visual fault-stress check,
corrected9/9 scene-congruency check, castle checks and64 castle review tests
pass. This does not produce an all-OK full validation result. First failures,
runner extraction correction, exact logs and later passes are retained.
