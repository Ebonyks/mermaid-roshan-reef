# Mermaid Roshan independent minigame review

Independently review every minigame and playable activity in Mermaid Roshan to improve its timing, teaching, feedback, challenge, variety and overall enjoyment for a non-reading four-year-old. Produce recommendations and reproducible experiments. This is a review commission; it does not commission game edits, generation, spending or release.

The scope extends well beyond jobs: **62 catalog entries**, including **15 careers**, picture and friend games, slides, rhythm play, cleanup and rescue, puzzles, action play, care and creative systems, plus world context. Aggregate entries expand into **54 named review units**; the current career table has **61 static phase rows**. These counts overlap and must not be added as unique minigames.

## Start here

1. Read [Review brief](REVIEW_BRIEF.md), [full game catalog](GAME_CATALOG.md) and [playtest protocol](PLAYTEST_PROTOCOL.md).
2. Record provider, actual exposed model/version, capabilities, date and source/build. Use source revision **`218ae766f8e60afb3f6338b8fafce28ec9fab7f2`** throughout. Packet date: October 31, 2026.
3. Declare an honest evidence lane: source analysis, simulated four-year-old walkthrough, playback review, actual desktop input, Android input or observed child play. Imagined behavior is not a played run or child observation.
4. Return the [report forms](REPORT_TEMPLATE.md), [JSON report](REPORT_TEMPLATE.json), [coverage ledger](COVERAGE_TEMPLATE.csv), and [event log](PLAYTHROUGH_LOG_TEMPLATE.csv). Every catalog ID and expanded unit requires a disposition, including inaccessible games.
5. Freeze your independent first report before reading other AI verdicts or [prior review context](AUTHORITY_AND_CONTEXT.md). Then add a separate reconciliation appendix. Binding product constraints in the brief apply from the beginning.

## Source and runtime access

[SOURCE_SNAPSHOT.zip](SOURCE_SNAPSHOT.zip) contains 326 immutable source and supporting files with hashes and direct raw URLs in [SOURCE_INDEX.json](SOURCE_INDEX.json). This is a code-review archive, not a runnable distribution or art reference packet. A chat model unable to unpack ZIP can fetch the immutable raw URLs for one family and its callers at a time. Do not quietly reduce the review to a few jobs when context fills.

A runtime-capable reviewer can check out [the exact game source tree](https://github.com/Ebonyks/mermaid-roshan-reef/tree/218ae766f8e60afb3f6338b8fafce28ec9fab7f2), read its AGENTS.md and SECURITY.md, and use exactly Godot 4.7.2-stable, Mobile renderer and Speedy tier, with a 1280 by 720 base canvas. Resolve the approved build with `python -B tools/resolve_godot.py` or `tools/run_godot.ps1`. The repository is large; source-only reviewers can use this smaller archive and mark runtime work pending.

[TIMING_SOURCE_INDEX.csv](TIMING_SOURCE_INDEX.csv) supplies source lines and owning functions for tuning candidates. These are search leads, not measured durations or proposed ideals. A mode's `goal` value is not assumed to mean seconds.

The stable and dev APK channels are mutable and cannot prove this source revision. Device reviews must record installed APK SHA-256, version code, build commit and matching CI receipt. A different build can be reviewed only when clearly identified separately. Use disposable test profiles/devices; preserve the family save and never uninstall or clear child data for testing.

## Independent review delivery

Give Claude, DeepSeek and later Codex the same manifest/request and source revision in separate conversations. Do not give one model's verdict to another before its independent first report is frozen. No external review is pre-filled here.

Paste this prompt into each review:

> Independently review every minigame and playable activity in this Mermaid Roshan packet. Follow REVIEW_BRIEF.md and PLAYTEST_PROTOCOL.md and use GAME_CATALOG.json for full coverage. Emulate a non-reading four-year-old with the declared synthetic profiles; distinguish simulation from actual runtime play and real child observation. Analyze timing, teaching, input comfort, feedback, agency, repetition, challenge, delight and rewards. Include non-job games, dormant activities and prototypes. Give current evidence, proposed parameter ranges with units, tradeoffs, reproducible experiments and success/revert criteria. Return the complete coverage ledger, per-game feedback profiles, playthrough reports, timing proposals and prioritized iteration plan. Freeze your independent first report before consulting prior AI verdicts. Report inaccessible tools/files, continue source analysis where possible and never invent playthroughs. Do not edit or release the game.

[MANIFEST.json](MANIFEST.json) owns the request ID, game manifest, payload list and hashes. [REMOTE_VERIFICATION.json](REMOTE_VERIFICATION.json) records exact-revision publication and anonymous access. Source-review readiness, actual playtests and gameplay acceptance are separate claims.

To verify a downloaded packet, run `python -B VERIFY_PACKET.py` from its directory. It checks every payload and archived source hash, catalog/coverage parity and local navigation without extracting files or making network requests.

[Stage alias coverage](STAGE_ALIAS_COVERAGE.json) reconciles every declared non-job minigame, picture and dance stage ID and six supporting overlay IDs with the catalog, including historical names that share an existing engine.

## Baseline verification

[LOCAL_VERIFICATION.json](LOCAL_VERIFICATION.json) separates passed packet checks and existing source CI from the completed local Windows suite: 82 probe processes ran, 79 exited zero, and three failed (combined playthrough/input guards, Geologist partner staging, and a Chapter 2 child-process deadline). The exact native log is retained. Causes are unconfirmed; no game or test changes were made. Machine results are not child observations. Publication is currently pending an owner exception to the repository's all-green commit rule.
