from pathlib import Path
import hashlib, json, zipfile
root=Path.cwd();out=root/"tmp/opera-music-20261017"
p=root/"audit/area_music/opera_melody_20261017/verification.json"
r=json.loads(p.read_text(encoding="utf-8"))
assert r["status"]=="PASS" and r["source_unchanged"]
assert len(r["probes"])==82 and all(x["pass"] and x["exit"]==0 for x in r["probes"])
assert r["static"]["exit"]==0 and r["import"]["exit"]==0 and r["game2d"]["exit"]==0
archive=p.with_name("verification_logs.zip")
with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(out.rglob("*")):
        if f.is_file() and f.suffix in {".log",".json",".py",".sh",".exit"}:
            z.write(f,f.relative_to(out).as_posix())
    for key in ("sources_before","sources_after"):
        z.writestr(key+".json",json.dumps(r[key],indent=2)+"\n")
    for relative in ("tools/build_area_music.py","tools/tests/test_authored_area_music.py","tools/tests/test_audit_audio_quality.py","assets_src/audio/music/area_music_scores.json"):
        z.write(root/relative,"sources/"+relative)
archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
for key in ("sources_before","sources_after"):
    r[key]={"count":r[key]["count"],"sha256":r[key]["sha256"],"complete_manifest":archive.name+":"+key+".json"}
r["evidence_archive"]={"path":archive.relative_to(root).as_posix(),"sha256":archive_hash,"bytes":archive.stat().st_size,"scope":"Lossless command logs, first incomplete candidate, full final source manifests, local drivers and exact composition/renderer/test sources. No protected audio payloads."}
p.write_text(json.dumps(r,indent=2)+"\n",encoding="utf-8")
ip=root/"design/audit_impacts/opera-melody-20261017.json";impact=json.loads(ip.read_text(encoding="utf-8"))
for v in impact["validation"]:
    if v["result"]=="PENDING":
        v["result"]="PASS"
        v["evidence"]="Final combined-source local gate PASS at "+r["baseline"]+"; source pin "+r["sources_before"]["sha256"]+"; see audit/area_music/opera_melody_20261017/verification.json and its hash-bound archive. All82 probes exit0; static prefix,44-cue verifier and857-row audio checker PASS; authored/policy tests34 PASS. Initial incomplete-static evidence is retained separately in the archive."
impact["reconciliation"]["final_source_sha256"]=r["sources_before"]["sha256"]
impact["evidence_archive_sha256"]=archive_hash
impact["publication_state"]="Local machine verification complete; exact published-head CI/integration tracked separately in the PR. Human/device/child/owner acceptance remains pending."
ip.write_text(json.dumps(impact,indent=2)+"\n",encoding="utf-8")
body="""The Opera venue cue wandered through rotating melodic fragments. Rework `castle_opera_hall` around an explicitly scored eight-bar D-major tune: a returning six-note Roshan hook, breathing answers, one higher response and a clear home cadence. Keep its 6/8 tempo, room ownership and loop duration; quiet the accompaniment beneath the centered clarinet.

The renderer's authored-bar option preserves exact pitches, durations, rests, dynamics and harmony. All43 unrelated cue binaries remain byte-identical. Register seven score regression cases in the existing audio CI gate, refresh the exact render/audio ledgers, and retain source/hash/rollback evidence in `design/audit_impacts/opera-melody-20261017.json`.

Validation: exact Godot4.7.2 import, migration regression and all82 trusted probes pass on the direct-foyer integration source; all44 music cues and857 audio rows verify; the audio policy/composition suite passes34 tests. Published-head CI is tracked by this PR. Owner comparison/materially better human grade, two-wrap/mono/voice listening and device/child acceptance remain pending; MA-AUDIO-001 stays FIXED_PENDING_VERIFICATION. No release or whole-game acceptance is claimed.
"""
(out/"pr-body.md").write_text(body,encoding="utf-8")
print("EVIDENCE",archive_hash,"PROBES82/82 STATIC_PASS SOURCE_UNCHANGED")
