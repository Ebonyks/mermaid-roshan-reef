from pathlib import Path
import concurrent.futures, hashlib, json, os, re, subprocess, tempfile, time
ROOT=Path(__file__).resolve().parents[2]
os.chdir(ROOT)
OUT=ROOT/'tmp/opera-music-20261017'
RECEIPT=ROOT/'audit/area_music/opera_melody_20261017/verification.json'
RECEIPT.parent.mkdir(parents=True,exist_ok=True)

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def frozen():
 paths=list(ROOT.glob('scripts/**/*.gd'))+list(ROOT.glob('scenes/**/*.tscn'))
 paths += [ROOT/x for x in ('project.godot','tools/build_area_music.py','assets_src/audio/music/area_music_scores.json','assets/audio/music/area_music_manifest.json','assets/audio/music/castle_opera_hall.ogg')]
 rows={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(paths)}
 return {'count':len(rows),'sha256':hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest(),'files':rows}
def run(command, name, env=None, timeout=1200):
 start=time.time(); log=OUT/(name+'.log')
 try:
  with log.open('w',encoding='utf-8') as f:
   ret=subprocess.run(command,cwd=ROOT,env=env or os.environ.copy(),stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
 except subprocess.TimeoutExpired:
  ret=124
 text=log.read_text(encoding='utf-8',errors='replace')
 record={'command':command,'exit':ret,'seconds':round(time.time()-start,3),'log_sha256':sha(log),'log':log.relative_to(ROOT).as_posix()}
 return record,text

ci=ROOT/'scripts/ci.sh'; ci_text=ci.read_text(encoding='utf-8')
receipt={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'ci_script_sha256':sha(ci),'method':'Exact scripts/ci.sh static prefix (only cwd rewritten to worktree), import, migration gate and unchanged full trusted probe list/flags; four independent profile-isolated subprocess workers. Static checks wait for the audio ledger and run independently of the game probes. No gameplay/probe changes.','status':'RUNNING'}
def save(): RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
save()
# Wait for the separately launched canonical render and first import to finish.
while 'MUSIC|result ALL OK|' not in (OUT/'build-final.log').read_text(errors='replace'):
 time.sleep(5)
while not (OUT/'import-initial.exit').exists():
 time.sleep(5)
receipt['sources_before']=frozen(); save()
godot=subprocess.check_output(['python','-B','tools/resolve_godot.py'],text=True).strip()
receipt['godot']={'path':godot,'sha256':sha(godot),'version':subprocess.check_output([godot,'--version'],text=True).strip()}
pre=ci_text.split('RUNTIME_ERROR_RE=')[0]
old='cd "$(dirname "$0")/.."'
assert old in pre
pre=pre.replace(old,"cd '"+ROOT.as_posix()+"'",1)
prepath=OUT/'ci-preflight.sh';prepath.write_text(pre,encoding='utf-8',newline='\n')
receipt['preflight_script_sha256']=sha(prepath)
def preflight():
 while not (OUT/'audio-ledger-write.exit').exists():
  time.sleep(5)
 if (OUT/'audio-ledger-write.exit').read_text().strip() != '0':
  return {'exit':1,'error':'Audio ledger refresh failed'}
 rec,txt=run(['C:/Program Files/Git/bin/bash.exe',str(prepath)],'full-static-gates',timeout=1800)
 print('STATIC',rec['exit'],flush=True)
 return rec
static_pool=concurrent.futures.ThreadPoolExecutor(max_workers=1)
static_future=static_pool.submit(preflight)
rec,txt=run([godot,'--headless','--path','.','--import'],'import-final',timeout=720)
receipt['import']=rec; save()
if rec['exit'] or re.search(r'SCRIPT ERROR|Parse Error|Compile Error|ERR_FILE_CORRUPT|Error importing|Cannot load resource',txt):
 receipt['status']='FAIL_IMPORT'; save(); raise SystemExit(1)
rec,txt=run(['python','-B','tools/audit_game_2d.py','--regression-gate'],'game2d-regression')
receipt['game2d']=rec; save()
if rec['exit']: receipt['status']='FAIL_2D'; save(); raise SystemExit(1)
probes=re.search(r'for p in (probe_reef_districts .*?); do',ci_text).group(1).split()
assert len(probes)==82, len(probes)
fail_re=re.compile(r'FAIL|FAILED|ISSUE|TIMEOUT|STUCK|DID NOT|MISSING|SCRIPT ERROR|Parse Error|Compile Error')
resource_re=re.compile(r'SCRIPT ERROR|Invalid assignment of property or key|The tweened property .* does not exist|ERROR:.*(Failed loading resource|Cannot open file|No loader found|Resource file not found)')
hybrid={'probe_passive','probe_touch_router','probe_touch_stress','probe_interaction','probe_touch_adversary'}
def probe(name):
 with tempfile.TemporaryDirectory(prefix='opera-gate-'+name+'-') as temp:
  profile=Path(temp); (profile/'roaming').mkdir(); (profile/'local').mkdir()
  env=os.environ.copy();env.update({'APPDATA':str(profile/'roaming'),'LOCALAPPDATA':str(profile/'local'),'XDG_DATA_HOME':str(profile/'data'),'XDG_CONFIG_HOME':str(profile/'config'),'PYTHONIOENCODING':'utf-8'})
  mode='--hybrid-touch-test' if name in hybrid else '--classic-touch-test'
  rec,txt=run([godot,'--headless','--path',str(ROOT),'-s','scripts/'+name+'.gd','--','--touch',mode],name,env,480)
  terminal_timeout=rec['exit']==124 and bool(re.search(r'ALL OK|RESULT','\n'.join(txt.splitlines()[-5:])))
  rec.update({'name':name,'pass':bool((rec['exit']==0 or terminal_timeout) and txt.strip() and not fail_re.search(txt) and not resource_re.search(txt)),'timeout_after_verdict':terminal_timeout})
  return rec
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 futures={pool.submit(probe,p):p for p in probes}
 for fut in concurrent.futures.as_completed(futures):
  row=fut.result();results.append(row)
  receipt['probes']=sorted(results,key=lambda r:probes.index(r['name'])); save()
  print('PROBE',len(results),len(probes),row['name'],row['exit'],row['pass'],flush=True)
receipt['static']=static_future.result();static_pool.shutdown();save()
receipt['sources_after']=frozen();receipt['source_unchanged']=receipt['sources_before']==receipt['sources_after']
receipt['status']='PASS' if all(r['pass'] for r in results) and receipt['source_unchanged'] and receipt['static']['exit']==0 else 'FAIL_STATIC_PROBES_OR_SOURCE_DRIFT'
receipt['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save()
print('FULL_GATE',receipt['status'],flush=True)
raise SystemExit(0 if receipt['status']=='PASS' else 1)
