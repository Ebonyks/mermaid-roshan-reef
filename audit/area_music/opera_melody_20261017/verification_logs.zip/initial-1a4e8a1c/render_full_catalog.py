"""Bounded local full-catalog driver; invokes the unchanged canonical render path."""
import concurrent.futures, json, os
from pathlib import Path
from tools import build_area_music as m
root=Path.cwd(); ff=m._find_ffmpeg(None,root); fp=m._find_ffprobe(ff)
catalog,cues=m._load_catalog(root)
generator=m._text_sha256(root/'tools/build_area_music.py')
scores=m._text_sha256(root/m.SCORES_PATH)
def render(cue):
 record=m._render_one(root,ff,fp,catalog,cue)
 print('MUSIC|rendered|'+cue['id'],flush=True)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 records=list(pool.map(render,cues))
assert m._text_sha256(root/'tools/build_area_music.py')==generator
assert m._text_sha256(root/m.SCORES_PATH)==scores
manifest=m._manifest(root,ff,catalog,records,generator,scores)
assert manifest['complete_catalog']
path=root/m.OUTPUT_DIR/m.MANIFEST_NAME
path.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print('MUSIC|result ALL OK|'+path.relative_to(root).as_posix(),flush=True)
