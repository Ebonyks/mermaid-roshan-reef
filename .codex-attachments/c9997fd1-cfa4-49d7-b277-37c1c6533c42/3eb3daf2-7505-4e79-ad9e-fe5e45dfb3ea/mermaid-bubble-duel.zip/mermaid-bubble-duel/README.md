# Reef of Light: Bubble Duel

A Mermaid Roshan arena game. Kick your tail to swim, keep your two bubbles, and pop your rival's bubbles by coming down on them from above. Don't sink into the trench, where Grumbletooth is waiting.

## Play

Open `index.html` in a browser (double-clicking works; no server or install needed). On a tablet, on-screen buttons appear automatically.

| | Player 1 / solo | Player 2 |
|---|---|---|
| Swim left / right | A / D (solo also: arrow keys) | Left / Right arrows |
| Tail kick (swim up) | W or Space (solo also: Up) | Up arrow |
| Use charm | S (solo also: Down) | Down arrow |
| Pause | P | |
| Back to reef | Esc | |

**Gentle mode** (on by default; toggle it on the reef map) makes the CPU slower, makes Roshan sink a little more gently, gives Grumbletooth a longer wind-up, never lowers your rank, and in Current Ride turns a jelly or trench touch into a lost bubble instead of game over (while you have a spare).

Add `?demo` to the URL to have the CPU play Roshan too, which is handy for watching art in motion.

## What's here

- `index.html`: the page. Plain scripts, so it runs from a file.
- `src/`: game code. `config.js` holds every tuning number, rival, stage, charm and price.
- `assets/manifest.js`: the only place the game looks for art (sizes, grids, anchors).
- `assets/**`: images. **Currently all placeholders.**
- `docs/CODEX_ART_HANDOFF.md`: the full brief for finishing the art.
- `docs/STUDY_NOTES.md`: how the original Flash game plays, the mechanics we matched, and what we deliberately didn't carry over.
- `docs/character_cell_guide.png`: hitbox and anchor layout for character sheets.
- `tools/`: `check_art.py` (validates art, writes a contact sheet), `ip_audit.py` (fails on any original names or files), `make_placeholders.py`.

## Provenance

The mechanics (flap physics, pop-from-above, bumping, lives, a bottom hazard, an energy-powered accessory, the CPU's priorities) were studied from *Balloon Duel* (John Su, Newgrounds, 2004). All code here was written fresh from our own notes, and no code, art, sound, text or names from that game, or from Nintendo's *Balloon Fight*, are included. `tools/ip_audit.py` enforces this.
