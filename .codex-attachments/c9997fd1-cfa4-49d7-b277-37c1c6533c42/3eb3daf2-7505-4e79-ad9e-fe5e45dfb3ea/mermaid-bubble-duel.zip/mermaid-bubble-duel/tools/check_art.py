#!/usr/bin/env python3
"""Validate every image in assets/manifest.js and (optionally) build a review contact sheet.

    python3 tools/check_art.py            # report
    python3 tools/check_art.py --sheet    # also writes review/contact_sheet.png
    python3 tools/check_art.py --strict   # exit 1 if any placeholder remains (release gate)

Checks: file exists, exact pixel size, RGBA, every animation cell has visible pixels,
sprite content touches the anchor area (catches art drawn off-anchor), and whether the
file is still a generated placeholder (PNG text chunk rl-placeholder=1).
"""
import json, os, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def load_manifest():
    j = subprocess.run(['node', os.path.join(ROOT, 'tools', 'dump_manifest.js')], capture_output=True, text=True, check=True).stdout
    return json.loads(j)['images']

def main():
    strict, sheet = '--strict' in sys.argv, '--sheet' in sys.argv
    imgs = load_manifest()
    problems, placeholders, done = [], [], []
    thumbs = []
    for key, d in imgs.items():
        path = os.path.join(ROOT, 'assets', d['file'])
        if not os.path.exists(path):
            problems.append(f'{key}: missing {d["file"]}'); continue
        im = Image.open(path)
        if im.info.get('rl-placeholder') == '1': placeholders.append(key)
        else: done.append(key)
        if im.size != (d['w'], d['h']):
            problems.append(f'{key}: size {im.size[0]}x{im.size[1]}, expected {d["w"]}x{d["h"]}')
        if im.mode != 'RGBA':
            problems.append(f'{key}: mode {im.mode}, expected RGBA')
            im = im.convert('RGBA')
        if 'cell' in d:
            cw, ch = d['cell']; ax, ay = d.get('anchor', [cw // 2, ch // 2])
            for name, a in d.get('anims', {}).items():
                for i in range(a['count']):
                    box = (i * cw, a['row'] * ch, (i + 1) * cw, (a['row'] + 1) * ch)
                    cell = im.crop(box)
                    bb = cell.getchannel('A').point(lambda v: 255 if v > 16 else 0).getbbox()
                    if not bb:
                        problems.append(f'{key}: {name} frame {i} is empty'); continue
                    # anchor should sit within (or within 12 px of) the drawn content
                    if not (bb[0] - 12 <= ax <= bb[2] + 12 and bb[1] - 12 <= ay <= bb[3] + 12):
                        problems.append(f'{key}: {name} frame {i} content {bb} is far from anchor ({ax},{ay})')
        thumbs.append((key, im))
    print(f'{len(done)} final, {len(placeholders)} placeholder, {len(problems)} problems')
    if placeholders: print('still placeholder: ' + ', '.join(placeholders))
    for p in problems: print('PROBLEM ' + p)
    if sheet: contact(thumbs)
    if problems or (strict and placeholders): sys.exit(1)

def contact(thumbs):
    os.makedirs(os.path.join(ROOT, 'review'), exist_ok=True)
    W, pad, lab = 1600, 16, 22
    try: f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 16)
    except Exception: f = ImageFont.load_default()
    rows, x, y, rowh = [], pad, pad, 0
    placed = []
    for key, im in thumbs:
        s = min(1.0, 380 / im.width, 300 / im.height)
        t = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))))
        if x + t.width + pad > W: x, y, rowh = pad, y + rowh + lab + pad, 0
        placed.append((key, t, x, y)); x += t.width + pad; rowh = max(rowh, t.height)
    H = y + rowh + lab + pad
    out = Image.new('RGBA', (W, H), (40, 44, 52, 255))
    checker = Image.new('RGBA', (16, 16), (70, 74, 82, 255))
    dr = ImageDraw.Draw(out)
    for key, t, x, y in placed:
        for cx in range(x, x + t.width, 16):
            for cy in range(y + lab, y + lab + t.height, 16):
                if ((cx - x) // 16 + (cy - y) // 16) % 2: out.paste(checker, (cx, cy))
        out.alpha_composite(t, (x, y + lab))
        dr.text((x, y), key, font=f, fill=(255, 255, 255, 255))
    p = os.path.join(ROOT, 'review', 'contact_sheet.png'); out.save(p); print('wrote ' + os.path.relpath(p, ROOT))

if __name__ == '__main__':
    main()
