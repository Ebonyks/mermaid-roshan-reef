// Prints assets/manifest.js as JSON. Usage: node tools/dump_manifest.js > manifest.json
const fs = require('fs'), path = require('path'), vm = require('vm');
const src = fs.readFileSync(path.join(__dirname, '..', 'assets', 'manifest.js'), 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(src.replace(/window\.RL = window\.RL \|\| \{\};/, 'window.RL = {}; var RL = window.RL;'), sandbox);
process.stdout.write(JSON.stringify(sandbox.window.RL.ASSETS, null, 2));
