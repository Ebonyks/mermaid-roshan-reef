#!/usr/bin/env python3
"""Generate placeholder PNGs for every entry in assets/manifest.js.

Each placeholder has the exact final size, cell grid and anchor, so the game runs
end to end before any real art exists. Every cell is labeled and shows its anchor.
Usage: python3 tools/make_placeholders.py [--force]
  (without --force, files that already exist are left alone, so real art is never overwritten)
"""
import json, os, subprocess, sys, math
from PIL import Image, ImageDraw, ImageFont, PngImagePlugin

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FORCE = '--force' in sys.argv

def save(im, path):
    meta = PngImagePlugin.PngInfo(); meta.add_text('rl-placeholder', '1')
    im.save(path, pnginfo=meta)

def font(size):
    for f in ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 'DejaVuSans-Bold.ttf']:
        try: return ImageFont.truetype(f, size)
        except Exception: pass
    return ImageFont.load_default()

PALETTE = {
    'roshan': (255, 140, 170), 'rival_tidbit': (255, 205, 90), 'rival_marlo': (160, 120, 90),
    'rival_inkwell': (170, 120, 230), 'rival_coralie': (90, 210, 190),
}
BG = {
    'bg_sunlit': ((120, 220, 245), (40, 140, 200)), 'bg_vents': ((255, 190, 130), (120, 60, 70)),
    'bg_kelp': ((110, 200, 190), (20, 90, 110)), 'bg_deep': ((30, 60, 120), (5, 10, 40)),
    'bg_ride': ((130, 225, 240), (30, 110, 170)), 'title_bg': ((150, 230, 250), (30, 90, 170)),
    'hub_map': ((120, 215, 230), (40, 120, 150)), 'shop_bg': ((245, 220, 180), (170, 120, 90)),
    'results_bg': ((200, 170, 250), (60, 60, 150)),
}

def gradient(w, h, top, bot):
    im = Image.new('RGBA', (w, h))
    d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / max(1, h - 1)
        d.line([(0, y), (w, y)], fill=tuple(int(top[i] + (bot[i] - top[i]) * t) for i in range(3)) + (255,))
    return im

def label(d, xy, text, size=14, fill=(255, 255, 255, 255)):
    f = font(size)
    x, y = xy
    d.text((x + 1, y + 1), text, font=f, fill=(0, 0, 0, 200))
    d.text((x, y), text, font=f, fill=fill)

def anchor_mark(d, ax, ay):
    d.line([(ax - 6, ay), (ax + 6, ay)], fill=(255, 0, 0, 255), width=2)
    d.line([(ax, ay - 6), (ax, ay + 6)], fill=(255, 0, 0, 255), width=2)

def draw_swimmer(d, cx, cy, col, anim, i, w, h):
    """Simple mermaid-ish blob facing right. cy = anchor (waist)."""
    sway = math.sin(i / 4 * 2 * math.pi) * 6
    if anim == 'kick': sway = [-14, 10, 16, 4][i % 4]
    if anim == 'tumble': sway = [0, 10, 0, -10][i % 4]
    tail = [(cx - 10, cy + 2), (cx + 10, cy + 2), (cx + 4 + sway, cy + 34), (cx - 4 + sway, cy + 34)]
    d.polygon(tail, fill=col + (255,))
    fin = [(cx + sway - 18, cy + 46), (cx + sway + 18, cy + 46), (cx + sway, cy + 32)]
    d.polygon(fin, fill=tuple(max(0, c - 50) for c in col) + (255,))
    d.ellipse([cx - 13, cy - 24, cx + 13, cy + 6], fill=(250, 220, 200, 255))        # torso
    d.ellipse([cx - 16, cy - 52, cx + 16, cy - 20], fill=(250, 220, 200, 255))       # head
    d.pieslice([cx - 20, cy - 58, cx + 20, cy - 18], 180, 360, fill=tuple(max(0, c - 70) for c in col) + (255,))  # hair
    eye = (40, 40, 60, 255)
    if anim == 'sad': d.line([(cx + 2, cy - 36), (cx + 10, cy - 34)], fill=eye, width=3)
    else: d.ellipse([cx + 4, cy - 40, cx + 10, cy - 33], fill=eye)
    if anim == 'cheer': d.line([(cx - 10, cy - 18), (cx - 22, cy - 46 - (i % 2) * 6)], fill=(250, 220, 200, 255), width=6)
    if anim == 'hurt': d.ellipse([cx - 30, cy - 70, cx + 30, cy - 10], outline=(255, 255, 255, 180), width=3)

def make(key, d_):
    path = os.path.join(ROOT, 'assets', d_['file'])
    if os.path.exists(path) and not FORCE: return 'kept'
    os.makedirs(os.path.dirname(path), exist_ok=True)
    w, h = d_['w'], d_['h']
    if key in BG:
        im = gradient(w, h, *BG[key]); dr = ImageDraw.Draw(im)
        for x in range(0, w, 300): dr.line([(x, 0), (x, h)], fill=(255, 255, 255, 40))
        label(dr, (30, h - 70), f'PLACEHOLDER  {key}  {w}x{h}', 34)
        if key == 'hub_map':
            for (x, y, t) in [(330, 330, 'Coral Arena'), (870, 330, 'Shell Shop'), (330, 620, 'Practice Lagoon'), (870, 620, 'Current Ride')]:
                dr.ellipse([x - 200, y - 110, x + 200, y + 110], outline=(255, 255, 255, 120), width=4)
        save(im, path); return 'made'
    if key == 'fg_trench':
        im = Image.new('RGBA', (w, h)); dr = ImageDraw.Draw(im)
        for y in range(h):
            a = int(255 * min(1, (y / h) ** 1.4 * 1.3))
            dr.line([(0, y), (w, y)], fill=(8, 16, 34, a))
        label(dr, (20, h - 30), 'PLACEHOLDER fg_trench', 18); save(im, path); return 'made'

    im = Image.new('RGBA', (w, h), (0, 0, 0, 0)); dr = ImageDraw.Draw(im)
    cell = d_.get('cell', [w, h]); cw, ch = cell
    anchor = d_.get('anchor', [cw // 2, ch // 2])
    anims = d_.get('anims', {'still': {'row': 0, 'count': 1}})
    for name, a in anims.items():
        for i in range(a['count']):
            x0, y0 = i * cw, a['row'] * ch
            ax, ay = x0 + anchor[0], y0 + anchor[1]
            if key in PALETTE:
                draw_swimmer(dr, ax, ay, PALETTE[key], name, i, cw, ch)
            elif key == 'bubble':
                r = 30 + (i % 2) * 2
                if name == 'pop':
                    for k in range(8):
                        ang = k * math.pi / 4; rr = 10 + i * 8
                        dr.ellipse([ax + math.cos(ang) * rr - 4, ay - 40 + math.sin(ang) * rr - 4, ax + math.cos(ang) * rr + 4, ay - 40 + math.sin(ang) * rr + 4], fill=(255, 255, 255, 230 - i * 50))
                else:
                    dr.ellipse([ax - r, ay - 2 * r - 6, ax + r, ay - 6], fill=(235, 245, 255, 170), outline=(255, 255, 255, 255), width=3)
                    dr.ellipse([ax - r // 2, ay - 2 * r + 4, ax - r // 2 + 12, ay - 2 * r + 16], fill=(255, 255, 255, 255))
                    dr.polygon([(ax - 5, ay - 6), (ax + 5, ay - 6), (ax, ay)], fill=(255, 255, 255, 220))
            elif key == 'tether':
                dr.line([(ax, 0), (ax, ch)], fill=(80, 150, 90, 255), width=4)
            elif key == 'grumbletooth':
                open_ = {'swim': 0.1, 'lunge': 0.2 + 0.2 * i, 'gulp': 0.05}[name]
                dr.ellipse([x0 + 30, y0 + 40, x0 + 210, y0 + 170], fill=(60, 70, 110, 255))
                dr.pieslice([x0 + 110, y0 + 50, x0 + 230, y0 + 150], -int(60 * open_ * 2) - 5, int(60 * open_ * 2) + 5, fill=(20, 15, 30, 255))
                dr.line([(x0 + 120, y0 + 50), (x0 + 150, y0 + 10), (x0 + 175, y0 + 18)], fill=(120, 140, 160, 255), width=4)
                dr.ellipse([x0 + 168, y0 + 8, x0 + 186, y0 + 26], fill=(255, 240, 140, 255))
                dr.ellipse([x0 + 140, y0 + 70, x0 + 156, y0 + 86], fill=(255, 255, 255, 255))
            elif key in ('jelly',):
                dr.pieslice([ax - 16, ay - 16, ax + 16, ay + 12], 180, 360, fill=(255, 140, 220, 220))
                for k in range(4): dr.line([(ax - 10 + k * 7, ay - 2), (ax - 10 + k * 7 + (i % 2) * 3, ay + 18)], fill=(255, 180, 240, 220), width=2)
            elif key in ('glow_pearl', 'icon_pearl'):
                r = cw // 2 - 4
                dr.ellipse([ax - r, ay - r, ax + r, ay + r], fill=(250, 245, 230, 255), outline=(255, 220, 160, 255), width=2)
            elif key.startswith('fx_'):
                col = {'fx_pop': (255, 255, 255), 'fx_splash': (200, 240, 255), 'fx_sparkle': (255, 240, 120), 'fx_ink': (40, 30, 60), 'fx_respawn': (200, 250, 255)}[key]
                rr = 8 + i * (cw // 10)
                dr.ellipse([ax - rr, ay - rr, ax + rr, ay + rr], outline=col + (230,), width=4)
                if key == 'fx_ink': dr.ellipse([ax - rr, ay - rr, ax + rr, ay + rr], fill=col + (150,))
            elif key == 'ui_button':
                dr.rounded_rectangle([x0 + 4, y0 + 4, x0 + cw - 4, y0 + ch - 4], 26, fill=(40, 150, 190, 235) if name == 'normal' else (255, 175, 90, 245), outline=(255, 255, 255, 255), width=4)
            elif key == 'hud_ready':
                dr.ellipse([x0 + 6, y0 + 6, x0 + cw - 6, y0 + ch - 6], fill=(255, 230, 90, 255) if i else (90, 80, 60, 255), outline=(255, 255, 255, 255), width=3)
            elif key == 'charm_icons':
                dr.rounded_rectangle([x0 + 6, y0 + 6, x0 + cw - 6, y0 + ch - 6], 18, fill=(60, 110, 170, 255), outline=(255, 255, 255, 255), width=3)
                label(dr, (x0 + 14, y0 + 36), ['none', 'fin', 'pearl', 'conch', 'wand', 'lasso', 'hush', 'ink'][i], 16)
            elif key == 'shopkeeper':
                dr.ellipse([x0 + 40, y0 + 90, x0 + 200, y0 + 236], fill=(230, 150, 110, 255))
                dr.ellipse([x0 + 90, y0 + 60, x0 + 115, y0 + 100 - i * 6], fill=(255, 255, 255, 255))
                dr.ellipse([x0 + 125, y0 + 60, x0 + 150, y0 + 100 - i * 6], fill=(255, 255, 255, 255))
            else:
                dr.rectangle([x0 + 2, y0 + 2, x0 + cw - 3, y0 + ch - 3], outline=(255, 0, 255, 255), width=2)
            if cw >= 48 and key not in ('ui_button',):
                label(dr, (x0 + 3, y0 + 2), f'{name}{i}', 11 if cw < 96 else 13, (255, 255, 0, 255))
            if key not in ('ui_button', 'tether') and cw >= 36: anchor_mark(dr, ax, ay)
    if key in ('hud_glow_frame',):
        dr.rounded_rectangle([0, 0, w - 1, h - 1], 20, fill=(20, 50, 90, 220), outline=(255, 255, 255, 255), width=4)
    if key == 'hud_glow_fill':
        im = gradient(w, h, (255, 240, 140), (255, 150, 90)); dr = ImageDraw.Draw(im)
    if key == 'hud_spare':
        dr.ellipse([3, 2, w - 4, h - 8], fill=(235, 245, 255, 220), outline=(255, 255, 255, 255), width=2)
    if key == 'title_logo':
        dr.rounded_rectangle([0, 0, w - 1, h - 1], 40, fill=(255, 255, 255, 60), outline=(255, 255, 255, 255), width=6)
        label(dr, (70, 90), 'Reef of Light', 96); label(dr, (190, 220), 'Bubble Duel', 80, (255, 220, 120, 255))
        label(dr, (20, h - 30), 'PLACEHOLDER title_logo', 18)
    save(im, path)
    return 'made'

def main():
    j = subprocess.run(['node', os.path.join(ROOT, 'tools', 'dump_manifest.js')], capture_output=True, text=True, check=True).stdout
    assets = json.loads(j)
    out = {}
    for key, d_ in assets['images'].items():
        out[key] = make(key, d_)
    made = sum(1 for v in out.values() if v == 'made')
    print(f'{made} placeholders written, {len(out) - made} existing files kept')

if __name__ == '__main__':
    main()
