#!/usr/bin/env python3
"""Fail if anything from the original Flash game (or Nintendo's) shows up in shipped files.

Checks every file except the provenance docs (README.md, docs/STUDY_NOTES.md, docs/CODEX_ART_HANDOFF.md),
which name the original on purpose, and this script. Run before every release and after every art drop:
    python3 tools/ip_audit.py
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKIP = {os.path.join('docs', 'STUDY_NOTES.md'), os.path.join('tools', 'ip_audit.py'),
        os.path.join('docs', 'CODEX_ART_HANDOFF.md'), 'README.md'}  # provenance docs name the original on purpose

# Names, places, items and lines from the original, plus the series it riffs on.
BANNED = [
    r'balloon\s*duel', r'mousekliks', r'john\s+su\b', r'balloon\s*fight', r'balloon\s*fighter', r'balloon\s*trip',
    r'nintendo', r'makkuro', r'kurosuke', r'\bcalvin\b', r'maple\s+leaf', r'head\s*wares?', r'fabric\s+fitters',
    r'meta\s*gene', r'gene\s+lab', r'antigrav', r'regrav', r'mag\s+magnum', r'flame\s*thrower',
    r'soldier\s+training', r'\bbpop\b', r'\bswf\b', r'ungrounded', r'newgrounds', r'ruffle',
    r'balloons\s*&\s*acc',
]
BIN_EXT = {'.png', '.jpg', '.jpeg', '.webp', '.ogg', '.mp3', '.wav'}
FORBIDDEN_EXT = {'.swf', '.fla', '.sol'}

def main():
    hits, checked = [], 0
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = [d for d in dn if d not in ('.git', 'node_modules')]
        for f in fn:
            rel = os.path.relpath(os.path.join(dp, f), ROOT)
            ext = os.path.splitext(f)[1].lower()
            if ext in FORBIDDEN_EXT:
                hits.append(f'{rel}: forbidden file type {ext}'); continue
            if rel in SKIP or ext in BIN_EXT: continue
            try: text = open(os.path.join(dp, f), encoding='utf-8').read()
            except Exception: continue
            checked += 1
            for pat in BANNED:
                for m in re.finditer(pat, text, re.I):
                    line = text.count('\n', 0, m.start()) + 1
                    hits.append(f'{rel}:{line}: "{m.group(0)}"')
    # PNG text chunks can carry tool/author strings; flag any that mention banned terms
    for dp, dn, fn in os.walk(os.path.join(ROOT, 'assets')):
        for f in fn:
            if f.lower().endswith('.png'):
                b = open(os.path.join(dp, f), 'rb').read()
                for pat in BANNED[:8]:
                    if re.search(pat.encode(), b, re.I):
                        hits.append(f'{os.path.relpath(os.path.join(dp, f), ROOT)}: banned text inside PNG metadata')
    print(f'checked {checked} text files')
    if hits:
        print('IP AUDIT FAILED:'); [print('  ' + h) for h in hits]; sys.exit(1)
    print('IP audit passed: no original names, text or files found.')

if __name__ == '__main__':
    main()
