# Codex handoff: art for *Reef of Light: Bubble Duel*

**Owner:** Peter Creed
**Your job:** replace every placeholder image in `assets/` with finished Mermaid Roshan art, rebuilt from the existing Reef of Light assets wherever possible, so the game ships with no placeholders.
**Not your job:** game code, physics, AI, audio, fonts. Touch `src/` only if this doc tells you to.

---

## 1. What this project is

A small 2D arena game for young children in the Mermaid Roshan / Reef of Light universe. Roshan floats in the water held up by two glowing bubbles on kelp strings. She flicks her tail to swim up and sideways. To win, she pops a rival's bubbles by coming down on them with her tail fin from above. Lose both bubbles and you sink into the trench, where Grumbletooth (a sleepy, silly anglerfish) waits. There's a reef-map hub, a Shell Shop, a Practice Lagoon, and a "Current Ride" bonus mode.

The game is **finished and playable**. All 34 images are generated placeholders (labeled shapes with red anchor crosses). Each has its final size, grid and anchor, so if you drop in a PNG with the same name, size and layout, it works with no code change.

## 2. Hard rule: original IP only

The game's *mechanics* were studied from a 2004 Flash game and its NES ancestor. **None of their art, characters, names, UI or sound may appear here.**

- Don't look up, trace, reference or imitate screenshots of *Balloon Fight*, *Balloon Duel*, or any Nintendo character. Work only from this doc and the Reef of Light repo (section 3).
- No third-party characters or styles you could name (no Disney mermaids, no Ghibli soot sprites, no Pokémon-like designs, and so on).
- Don't bake text into images, except the title logo.
- Fonts: if you make the logo from a font, it must be OFL/Apache-licensed. Write the font name in `art-src/CREDITS.md`.
- Run `python3 tools/ip_audit.py` before every commit. It has to pass.

## 3. Source of truth: the Reef of Light repo and its master audit

**Don't invent art direction. Rebuild from what already exists.** Mermaid Roshan already has an established world, character designs, style rules and thousands of accepted assets in Peter's main repo. Every art decision comes from that repo first. Section 4 (style) is a fallback for where the repo is silent. Section 5 (technical rules) always applies, because it's what makes the art work in this game.

**Repo:** `https://github.com/Ebonyks/mermaid-roshan-reef`, branch `dev`. It's large; a full clone times out. Use a blobless sparse checkout and add paths as you need them:

```bash
git clone --depth 1 --branch dev --filter=blob:none --no-checkout https://github.com/Ebonyks/mermaid-roshan-reef reef
cd reef && git sparse-checkout init --no-cone
printf '%s\n' '/AGENTS.md' '/CLAUDE.md' '/design/' '/audit/MASTER_AUDIT_2026-08-09.md' '/audit/MASTER_AUDIT_2026-08-26.md' > .git/info/sparse-checkout
git checkout dev
git ls-tree -r --name-only HEAD > ../reef_tree.txt   # full file list without downloading blobs
```

### 3.1 Required reading, in this order

1. `audit/MASTER_AUDIT_2026-08-09.md`: the **canonical master audit**. Read section 0 (planning entry), section 3 (authority and precedence), and any `MA-VIS-*`, `MA-2D-*` and art findings. Where documents disagree, follow its section 3.1 precedence.
2. `audit/MASTER_AUDIT_2026-08-26.md`: the newest supporting round (context only; it is about code).
3. `AGENTS.md`: binding rules on protected assets, reuse-before-generation, and provenance.
4. `design/00_MASTER_INDEX.md`, then `design/06_COMPREHENSIVE_DESIGN_LANGUAGE.md` (the canonical `DL-*` rules, especially visual, motion, child-safety and provenance) and `design/02_ART_DIRECTION.md`.
5. `design/animation/ROSHAN_MOVEMENT_LANGUAGE.md` and `design/animation/ANIMATION_PRODUCTION_PROTOCOL.md`, for how Roshan moves (the tail kick, idle and cheer must follow these).
6. `design/10_CHAPTER_REFERENCE_LIBRARY.md` (asset discovery) and `design/09_CHAPTER_DEVELOPMENT_GUIDE.md` (strategic reuse of existing assets).
7. `ASSET_LICENSES.md` (about 6 MB; grep it, don't read it whole): the provenance ledger. Use it to check every asset you consider reusing.

**What carries over and what doesn't.** This game is a separate HTML5 project. The Reef repo's **art, character, style, motion, child-safety, protected-asset and provenance rules apply here in full.** Its Godot engine rules, probe suite, CI and release gates do not; don't try to run them.

### 3.2 Reuse-first protocol (mandatory, for every asset in section 6)

Work through the manifest one key at a time:

1. **Search.** Grep `reef_tree.txt` and the design docs for the subject (for example `seahorse`, `otter`, `octopus`, `bubble`, `pearl`, `kelp`, `coral`, `jelly`, `crab`, `roshan.*swim`). Check out only the candidate files you need.
2. **Check eligibility.** A candidate is usable only if (a) `ASSET_LICENSES.md` shows it as family-made or own-style generated, not third-party, and (b) the master audit doesn't mark it superseded, rejected or migration debt. Treat anything you can't trace in the ledger as ineligible.
3. **Decide**, in this order of preference:
   - **REUSE:** use it as is (resized and re-anchored into the cell).
   - **DERIVE:** build the new frames or poses from it (repose, recolor, extend, paint over), keeping the design on model.
   - **GENERATE (gap only):** allowed only when step 1 found nothing suitable, or reuse would clearly fail the purpose or quality bar. Write down the specific gap first, and generate only to fill it. Condition the generation on the closest eligible repo references so the result matches the established style.
4. **Record** the decision in `art-src/ASSET_DECISIONS.md`, one row per manifest key: key, decision (REUSE / DERIVE / GENERATE), source paths in the Reef repo with their commit SHA, the `ASSET_LICENSES.md` line or lines that clear them, the rules applied (`DL-*` IDs and audit IDs), and for GENERATE the recorded gap. A row with no repo evidence behind it is a failed row.
5. **Provenance.** Add a matching line to `art-src/CREDITS.md` for every shipped PNG, in the same style as `ASSET_LICENSES.md`.

**Protected originals.** Never modify, recompress or substitute anything in the Reef repo, and in particular `assets/book/`, `assets/audio/voices/` and `assets/characters/friends/`. You may read them as references. Don't build rival or hazard sprites from the friend portraits in `assets/characters/friends/` unless Peter explicitly asks for it. All derived work goes to new paths in this project.

### 3.3 Leads found on Reef `dev` (verify each one; these are starting points, not approvals)

| Need | Existing candidates on `dev` |
|---|---|
| Roshan swimming, base and gestures | `assets/characters/roshan_25d/roshan_swim.png`, `roshan_base.png`, `roshan_play*.png`, `roshan_gesture_*.png`; animation work under `assets_src/animation/` (wave repair, whole-sprite pipeline). Use the current accepted Roshan frame roster named in the master audit's authority map (the `tools/audit_roshan_sprite_clipping.py` roster), not superseded drafts. |
| Seahorse rival | 57 seahorse images, including `assets/castle/day_one_pool/activities/seahorse_*` |
| Otter rival | `assets/sprites/sky_lagoon/animals/otter_idle_atlas.png`, `otter_startle_atlas.png` |
| Octopus rival | about 20 octopus images, including `assets/aquatic2/Octopus_normal.png` (provenance not yet confirmed; check the ledger before using it) |
| Mermaid champion rival | Search the canon for an existing mermaid character before designing one (the audit references Rumi, Harper and Fiona). |
| Trench hazard | No anglerfish exists. About 13 fish images exist (for example `assets/art35/cards/gen2/clownfish_side_*`, `assets/art35/cards/mg/fish_body_*`); use them as style references. A big trench fish is the most likely real generation gap. (Grand Puff is a dust-bunny boss, not a fish.) |
| Bubbles, splash, pop FX | 119 bubble images, including `assets/castle/dirty_cleanup_2d/effects/fx_soap_bubbles.png` and the bubble-bath interaction atlases |
| Pearls and currency | about 280 pearl images (note: `pearl_friend.png` is a protected friend portrait, not a pickup) |
| Kelp, coral, shells (backgrounds, tether, icons) | `assets/props/gen2/kelp.png`, `assets/art35/cards/gen2/` (coral, fan shells) |
| Crab shopkeeper | `assets/aquatic2/Crab_normal.png` (provenance not yet confirmed) |
| Backgrounds | Existing reef, pool and lagoon art; the Sky Lagoon panoramas under `assets_src/sky_lagoon/masters/` show the established painted-environment standard |

**Names.** If the canon already has names for the characters you reuse, use those names. You may edit the `name` fields in `RL.RIVALS` in `src/config.js` and the `notes` strings in `assets/manifest.js` for this. Don't change any IDs, sizes, cells or anchors. Record every rename in `ASSET_DECISIONS.md`.

## 4. Style guide (fallback only)

The repo's `design/02_ART_DIRECTION.md`, `design/06_COMPREHENSIVE_DESIGN_LANGUAGE.md` and the existing accepted assets win over everything in this section. Use the notes below only where the repo is silent, and say so in `ASSET_DECISIONS.md` when you do.

**Overall look.** A bright storybook reef. The Reef of Light direction is **Wind Waker-style staging** (clear shapes, bold silhouettes, readable from far away), **Cult of the Lamb-style motion** (squash and stretch, snappy anticipation, bouncy settles), and a **painterly surface** (soft gradients and brush texture inside clean shapes).

**Readability comes first.** A character is drawn at about 96 x 128 px on a 1200 x 900 canvas, and the game is often played on an older Android tablet. So:

- Thick, soft, dark outlines (3 to 4 px) on characters, bubbles, the hazard and pickups. Backgrounds get no outlines, or very light ones.
- Characters and props are high-contrast and saturated. Backgrounds are lower contrast and slightly desaturated, so the play layer pops.
- Faces are big and simple: large eyes, clear mouth shapes. Every expression is friendly. "Sad" means pouty, never distressed.
- No scary content. Grumbletooth is a big, sleepy, grumpy-silly fish with a glowing lure and a goofy underbite. No sharp teeth that read as dangerous, no blood, no eyes that read as menacing.

**Palette anchors** (replace these with the colors sampled from the reused Reef assets):

| Role | Colors |
|---|---|
| Sunlit water | `#7fe6ff` to `#2a8cc8` (top to bottom) |
| Deep water | `#1e3c78` to `#050a28` |
| Warm vents | `#ffbe82` to `#783c46` |
| Kelp | `#6ec8be` to `#145a6e` |
| Outline | `#14243a` (dark navy, not pure black) |
| Glow / highlight | `#fff6c8` |

**Characters.** Each one faces **right**; the game mirrors them for left (this matches the Reef rule of left/right facing only, whole-sprite frames and constant character size). Silhouettes must be easy to tell apart at small size. The species below already match existing Reef assets (section 3.3); take the actual designs from those assets:

| Key | Character | Silhouette idea |
|---|---|---|
| `roshan` | Roshan, the hero mermaid | Must be on model with the accepted Reef Roshan. Never redesign her. |
| `rival_tidbit` | Tidbit the Seahorse, a kid | Curly tail, snout, small crest. Easiest rival, cute. |
| `rival_marlo` | Marlo the Otter | Round body, whiskers, floats on his back in idle. |
| `rival_inkwell` | Inkwell the Octopus | Big head, 4 visible curling arms in place of a tail. Wears little spectacles. |
| `rival_coralie` | Coralie the Mermaid, the champion | Clearly different from Roshan: different hair shape and tail color, coral crown. |

**Bubbles.** Draw them **near-white and pale gray, semi-transparent** (body alpha about 0.55 to 0.75, rim and highlight opaque). The game tints them with a multiply blend for each character's color, so any color you paint gets multiplied. Keep them neutral. Add one strong highlight and a little knot where the tether attaches at the bottom.

## 5. Technical rules (the checker enforces these)

- **PNG, RGBA, transparent background**, except the backgrounds and screens (`bg_*`, `title_bg`, `hub_map`, `shop_bg`, `results_bg`), which are opaque.
- **Exact pixel size** from the table below. Don't resize, crop or pad.
- **Sprite sheets:** fixed-size cells in a grid. **One animation per row**, frames left to right, starting at column 0. Unused cells stay fully transparent.
- **Anchor:** the pixel inside each cell that sits on the object's world position. It's the same for every frame in a sheet. Keep the body planted on it, so the character doesn't drift between frames.
- **Stay inside the cell.** Nothing may cross into a neighboring cell.
- **Scale:** 1 world unit = 3 px. The game renders at 1200 x 900 and scales down on smaller screens.
- No baked drop shadows on sprites (the background shows through the water).

### Character sheets (all five use this layout)

`384 x 768` px = 4 columns x 6 rows of `96 x 128` cells. **Anchor `(48, 74)` = waist.** See `docs/character_cell_guide.png` for where the hitboxes are.

| Row | Anim | Frames | Plays | What to draw |
|---|---|---|---|---|
| 0 | `idle` | 4 | loop, 6 fps | Treading water: gentle tail sway, hair drifting, small breath. |
| 1 | `kick` | 4 | once, 18 fps | One strong tail flick, the "flap": 0 anticipation (tail curls down, body squashes), 1 snap (tail whips, body stretches up), 2 follow-through, 3 settle. Plays on every button press, so it must read in a quarter second. |
| 2 | `tumble` | 4 | loop, 10 fps | Out of bubbles, sinking: arms flailing upward, worried "whoa!" face. Still funny, not scary. |
| 3 | `hurt` | 2 | once, 8 fps | Just lost a bubble: surprised flinch, eyes squeezed shut. |
| 4 | `cheer` | 4 | loop, 8 fps | Won: arms up, tail flips, sparkle eyes. |
| 5 | `sad` | 2 | loop, 3 fps | Lost: pouty slump, small frown. Sweet, not crushed. |

The head top should land about 52 to 58 px above the anchor; the bubbles start 72 px above it. The tail fin tip should land 27 to 48 px below the anchor, inside the FIN box. That's the part that pops bubbles, so make the fin a clear shape.

## 6. Asset list

**Priorities.** P0 = the arena is playable and looks finished with just these. P1 = all arena content. P2 = screens and polish. Deliver in that order and commit after each priority.

| Pri | Key | File | Size (px) | Grid / animations | Anchor | Notes |
|---|---|---|---|---|---|---|
| P0 | `roshan` | `assets/sprites/roshan.png` | 384x768 | 96x128 cells; idle 4f, kick 4f, tumble 4f, hurt 2f, cheer 4f, sad 2f | 48,74 | Hero. Mermaid Roshan. Faces right; game mirrors for left. |
| P0 | `bubble` | `assets/sprites/bubble.png` | 288x168 | 72x84 cells; wobble 4f, pop 4f | 36,78 | One bubble. Drawn twice per fighter. Anchor = where the tether meets the bubble. Neutral/white, tinted at runtime. Pop row: bubble bursts into droplets and sparkles, gone by frame 3. |
| P0 | `tether` | `assets/sprites/tether.png` | 12x60 | 12x60 cells; still 1f | 6,60 | Kelp string from waist to bubble. Stretched vertically by the game, so keep detail even along its length. |
| P0 | `grumbletooth` | `assets/sprites/grumbletooth.png` | 960x540 | 240x180 cells; swim 4f, lunge 4f, gulp 2f | 120,60 | Sleepy trench anglerfish. Faces right. Anchor = top of mouth. Lure bobs above the head. Lunge: mouth opens wide, lure swings forward. Gulp: cheeks puffed, mouth closed, eyes wobbly (there's a swimmer inside, about to be spat back up). Grumpy-silly, never scary. |
| P0 | `bg_sunlit` | `assets/bg/sunlit.png` | 1200x900 | single image | top-left | Bright shallow reef, god rays. Water surface line across the top 60 px. Busy detail only along the bottom third. |
| P0 | `fg_trench` | `assets/bg/trench.png` | 1200x150 | single image | top-left | Dark trench lip drawn over every arena at world y 250..300. Top edge fades to fully transparent; Grumbletooth hides behind the dark bottom. Rocks and coral silhouettes along the bottom. |
| P0 | `fx_pop` | `assets/fx/pop.png` | 384x96 | 96x96 cells; play 4f | 48,48 | Bubble pop burst (ring + droplets + stars). |
| P0 | `hud_glow_frame` | `assets/ui/glow_frame.png` | 330x60 | single image | top-left | Energy ("glow") meter frame. Inner fill area: x 12..318, y 18..42 must be clear. |
| P0 | `hud_glow_fill` | `assets/ui/glow_fill.png` | 306x24 | single image | top-left | Meter fill, cropped from the left by the game. Warm glow gradient. |
| P0 | `hud_ready` | `assets/ui/ready.png` | 96x48 | 48x48 cells; frame 0 off, frame 1 on | 24,24 | Charm-ready light (a little sea-glass lamp). |
| P0 | `hud_spare` | `assets/ui/spare.png` | 30x36 | single image | top-left | Small spare-life bubble icon. |
| P0 | `ui_button` | `assets/ui/button.png` | 480x120 | 480x60 cells; normal, hover | 240,30 | Rounded sea-glass pill. Row 0 normal (cool), row 1 selected (warm, brighter). Game writes the text on top, so keep the center flat enough for white text with a dark outline. |
| P1 | `rival_tidbit` | `assets/sprites/rival_tidbit.png` | 384x768 | same as `roshan` | 48,74 | Rival 1, easiest. Seahorse kid. |
| P1 | `rival_marlo` | `assets/sprites/rival_marlo.png` | 384x768 | same as `roshan` | 48,74 | Rival 2. Otter. |
| P1 | `rival_inkwell` | `assets/sprites/rival_inkwell.png` | 384x768 | same as `roshan` | 48,74 | Rival 3. Octopus. |
| P1 | `rival_coralie` | `assets/sprites/rival_coralie.png` | 384x768 | same as `roshan` | 48,74 | Rival 4, hardest. Mermaid champion. Also used for player 2 in two-player mode. |
| P1 | `bg_vents` | `assets/bg/vents.png` | 1200x900 | single image | top-left | Warm orange vents, rising shimmer. (Bubbles slowly grow here.) |
| P1 | `bg_kelp` | `assets/bg/kelp.png` | 1200x900 | single image | top-left | Cool blue-green kelp forest. (Bubbles slowly shrink here.) |
| P1 | `bg_deep` | `assets/bg/deep.png` | 1200x900 | single image | top-left | Dark water, bioluminescent dots. Must still give strong contrast behind the characters. |
| P1 | `fx_splash` | `assets/fx/splash.png` | 384x96 | 96x96 cells; play 4f | 48,80 | Bonk against the water surface from below. |
| P1 | `fx_respawn` | `assets/fx/respawn.png` | 384x96 | 96x96 cells; play 4f | 48,48 | Rising bubble column when a swimmer relaunches from the trench. |
| P1 | `fx_sparkle` | `assets/fx/sparkle.png` | 192x48 | 48x48 cells; play 4f loop | 24,24 | Sparkle Wand shot (travels sideways). |
| P1 | `fx_ink` | `assets/fx/ink.png` | 576x144 | 144x144 cells; play 4f loop | 72,72 | Ink Puff cloud around a held rival. Soft, cartoony, semi-transparent. |
| P2 | `jelly` | `assets/sprites/jelly.png` | 192x48 | 48x48 cells; drift 4f | 24,24 | Zappy jellyfish (Current Ride hazard). Clearly "don't touch": little zig-zag sparks. |
| P2 | `glow_pearl` | `assets/sprites/pearl.png` | 144x36 | 36x36 cells; shine 4f | 18,18 | Pearl pickup with a rotating glint. |
| P2 | `icon_pearl` | `assets/ui/icon_pearl.png` | 48x48 | single image | top-left | Currency icon (matches `glow_pearl`). |
| P2 | `bg_ride` | `assets/bg/ride.png` | 2400x900 | single image | top-left | Current Ride. **Tiles horizontally**: the left and right edges must match pixel for pixel. Streaming current lines. |
| P2 | `title_logo` | `assets/ui/title_logo.png` | 900x360 | single image | top-left | Wordmark, exactly: "Reef of Light" (smaller) over "Bubble Duel" (bigger). Transparent background. |
| P2 | `title_bg` | `assets/ui/title_bg.png` | 1200x900 | single image | top-left | Title backdrop. Keep x 150..1050, y 80..440 calm for the logo; Roshan is drawn at about (600, 690). |
| P2 | `hub_map` | `assets/ui/hub_map.png` | 1200x900 | single image | top-left | Painted reef map with 4 places centered at (330,330) Coral Arena, (870,330) Shell Shop, (330,620) Practice Lagoon, (870,620) Current Ride. A button is drawn across each center (480 x 60), so put each place's landmark art around and above its button. Top 90 px and bottom 120 px are HUD and button zones. |
| P2 | `shop_bg` | `assets/ui/shop_bg.png` | 1200x900 | single image | top-left | Shell Shop interior. A grid of buttons covers x 120..1120, y 220..650; keep that area low-contrast. |
| P2 | `results_bg` | `assets/ui/results_bg.png` | 1200x900 | single image | top-left | Results. Characters stand at about (420, 600) and (810, 600); title text across the top 300 px. |
| P2 | `shopkeeper` | `assets/sprites/shopkeeper.png` | 480x240 | 240x240 cells; talk 2f | 120,240 | Shell Shop host, a hermit crab with a big decorated shell. Drawn small, top-left. 2-frame talk loop. |
| P2 | `charm_icons` | `assets/ui/charms.png` | 768x96 | 96x96 cells; 8 icons in one row | 48,48 | In order: none (empty shell), Wind-Up Fin (fin with a wind-up key), Float Pearl, Current Conch, Sparkle Wand, Kelp Lasso, Hush Shell, Ink Puff. |

## 7. How to work

```bash
# run the game (either works)
open index.html                       # double-click also works; no server needed
python3 -m http.server 8000           # then http://localhost:8000
# ?demo  -> the CPU plays Roshan too, so you can watch a whole bout without touching the keys

# after each batch of art
python3 tools/check_art.py --sheet    # size/grid/anchor checks + review/contact_sheet.png
python3 tools/ip_audit.py             # must pass
```

- Keep editable sources (layered files, SVG, prompts, seeds) in `art-src/<key>/`. Exports go only to `assets/`.
- Generation is allowed only for gaps recorded under section 3.2. When you generate, use the eligible Reef assets as references, generate **per frame or per pose**, then assemble sheets with a script that places each frame on its cell and anchor. Never stretch a generated image to fit a sheet. Keep the prompts in `art-src/<key>/prompt.md`. Characters must stay **on model** across all 20 frames: same proportions, colors and outline weight. Run a consistency pass before committing.
- A vector pipeline (SVG per frame, rendered to PNG) is a good fallback for HUD, UI, FX and pickups.
- `tools/make_placeholders.py` never overwrites existing files, so it's safe to run at any time.
- **Don't change** `assets/manifest.js` sizes, cells or anchors. If a design truly needs a different cell size, stop and write the request in `art-src/REQUESTS.md` for Peter.

## 8. Acceptance checklist (per asset)

- [ ] `art-src/ASSET_DECISIONS.md` has a row for it, with Reef repo source paths and commit SHA, ledger clearance, and (for GENERATE only) the recorded gap.
- [ ] Reused or derived characters are on model with their Reef originals. Compare them side by side in `review/`.
- [ ] `check_art.py` shows no problems, and the asset is no longer listed as placeholder.
- [ ] It looks right in game at full size **and** at a 50% browser window (tablet size).
- [ ] Characters: the anchor sits on the waist in every frame. No sliding in `idle`. The kick reads as a kick at 18 fps. The mirrored version looks right (no backwards text or asymmetric logos).
- [ ] The fin lands inside the FIN box in every frame (see the cell guide).
- [ ] Bubbles tint cleanly in all 5 shop colors and every rival tint (check the Shell Shop's bubble colors and each rival bout).
- [ ] `fg_trench` fades fully transparent at the top. Grumbletooth is hidden at rest and visible while lunging.
- [ ] `bg_ride` tiles with no visible seam (watch for 20 seconds in Current Ride).
- [ ] Nothing scary. A 4-year-old would find Grumbletooth funny.
- [ ] `ip_audit.py` passes.

**Done** = `python3 tools/check_art.py --strict` exits 0 (no placeholders left), the IP audit passes, every manifest key has an evidence-backed row in `ASSET_DECISIONS.md`, and `review/contact_sheet.png` plus in-game screenshots of every screen are committed for Peter's review.

## 9. Paste-ready prompt for Codex

> You are completing the art for *Reef of Light: Bubble Duel*, an HTML5 canvas game in this repo. Read `docs/CODEX_ART_HANDOFF.md` fully before starting and follow it exactly.
>
> This game belongs to the existing Mermaid Roshan universe. **Don't generate ideas at random; rebuild from what already exists.** Search Peter's main repo, `https://github.com/Ebonyks/mermaid-roshan-reef` (branch `dev`, blobless sparse checkout as described in section 3), and make every art decision from what's available there. Use the master audit, `audit/MASTER_AUDIT_2026-08-09.md`, as the authority: follow its section 3 precedence, then `AGENTS.md`, `design/06_COMPREHENSIVE_DESIGN_LANGUAGE.md`, `design/02_ART_DIRECTION.md` and the Roshan animation docs.
>
> For every image in `assets/manifest.js`, follow the reuse-first protocol in section 3.2: search the Reef repo, confirm eligibility in `ASSET_LICENSES.md` and the master audit, then REUSE, DERIVE, or (only for a recorded gap) GENERATE using the closest eligible Reef assets as references. Record each decision with its evidence in `art-src/ASSET_DECISIONS.md`. Roshan must stay on model with her accepted Reef design. Never modify protected Reef originals (`assets/book/`, `assets/audio/voices/`, `assets/characters/friends/`), and don't build sprites from the friend portraits unless Peter asks.
>
> Keep each file's name, pixel size, cell grid and anchor. Don't edit game code or manifest geometry; the only text edits allowed are rival names in `src/config.js` and manifest `notes`, and only to match established canon names. Don't reference or imitate *Balloon Fight*, *Balloon Duel* or any non-Reef game or character. Work in priority order P0, then P1, then P2, committing after each.
>
> After each batch, run `python3 tools/check_art.py --sheet` and `python3 tools/ip_audit.py` and fix anything they report. Finish when `python3 tools/check_art.py --strict` exits 0 and every manifest key has an evidence-backed decision row. Commit `review/contact_sheet.png`, side-by-side comparisons of each reused character against its Reef original, and a screenshot of each screen (title, hub, shop, the arena on all four stages, results, practice, current ride). List anything that needs Peter's decision at the top of `ASSET_DECISIONS.md`.
