// Boot + fixed 30 fps loop.
(function () {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  RL.Input.bindTouch(canvas, document.getElementById('pad'));
  RL.Save.load();

  let acc = 0, last = performance.now();
  const STEP = 1000 / RL.CONFIG.FPS;
  RL.debug = { frames: 0 };

  function frame(now) {
    acc += Math.min(250, now - last); last = now;
    let steps = 0;
    while (acc >= STEP && steps < 5) {
      const s = RL.scene();
      if (s && s.update) s.update();
      RL.Input.endFrame();
      acc -= STEP; steps++; RL.debug.frames++;
    }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const s = RL.scene();
    if (s && s.draw) s.draw(ctx);
    requestAnimationFrame(frame);
  }

  function loading() {
    ctx.fillStyle = '#0b2a44'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    RL.drawText(ctx, `Loading the reef… ${Math.round(RL.Assets.progress() * 100)}%`, 600, 450, 44, 'center');
  }
  loading();
  const tick = setInterval(loading, 100);
  RL.Assets.load(() => {
    clearInterval(tick);
    const missing = RL.Assets.failed();
    if (missing.length) console.warn('Missing art (drawing pink placeholders):', missing.join(', '));
    RL.go(RL.Title());
    requestAnimationFrame(frame);
  });
})();
