// Placeholder sound: tiny synthesized blips, no recorded audio.
// Final sound design is out of scope for the art handoff; swap these for files later.
(function () {
  let ac = null;
  const ensure = () => { if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } return ac; };
  addEventListener('pointerdown', ensure, { once: true });
  addEventListener('keydown', ensure, { once: true });

  function tone(f0, f1, dur, type = 'sine', vol = 0.15) {
    const a = ensure(); if (!a) return;
    const o = a.createOscillator(), g = a.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, a.currentTime);
    o.frequency.exponentialRampToValueAtTime(Math.max(f1, 1), a.currentTime + dur);
    g.gain.setValueAtTime(vol, a.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, a.currentTime + dur);
    o.connect(g).connect(a.destination); o.start(); o.stop(a.currentTime + dur);
  }
  RL.Sfx = {
    kick()    { tone(220, 330, 0.08, 'triangle', 0.08); },
    pop()     { tone(900, 200, 0.12, 'square', 0.08); tone(1400, 600, 0.06, 'sine', 0.06); },
    bonk()    { tone(160, 90, 0.12, 'sine', 0.12); },
    splash()  { tone(500, 120, 0.2, 'sawtooth', 0.04); },
    launch()  { tone(200, 800, 0.35, 'sine', 0.1); },
    gulp()    { tone(120, 60, 0.4, 'triangle', 0.15); },
    charm()   { tone(600, 1200, 0.15, 'sine', 0.08); },
    pearl()   { tone(1200, 1800, 0.1, 'sine', 0.06); },
    win()     { [523, 659, 784].forEach((f, i) => setTimeout(() => tone(f, f, 0.18, 'triangle', 0.1), i * 140)); },
    lose()    { [392, 330, 262].forEach((f, i) => setTimeout(() => tone(f, f, 0.22, 'triangle', 0.08), i * 180)); },
    click()   { tone(700, 700, 0.04, 'square', 0.04); },
  };
})();
