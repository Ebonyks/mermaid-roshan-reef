// Asset loading and sprite drawing. Reads RL.ASSETS from assets/manifest.js.
(function () {
  const S = () => RL.CONFIG.RENDER_SCALE;
  const imgs = {};
  const tintCache = {};
  let loaded = 0, total = 0, failed = [];

  RL.Assets = {
    load(onDone) {
      const list = Object.entries(RL.ASSETS.images);
      total = list.length;
      if (!total) return onDone();
      list.forEach(([key, def]) => {
        const im = new Image();
        im.onload = () => { imgs[key] = im; if (++loaded + failed.length === total) onDone(); };
        im.onerror = () => { failed.push(key); if (loaded + failed.length === total) onDone(); };
        im.src = RL.ASSETS.base + def.file;
      });
    },
    progress() { return total ? (loaded + failed.length) / total : 1; },
    failed() { return failed.slice(); },
    has(key) { return !!imgs[key]; },
    def(key) { return RL.ASSETS.images[key]; },

    frameFor(key, anim, t) {
      const d = RL.ASSETS.images[key];
      if (!d || !d.anims) return { row: 0, col: 0, done: true };
      const a = d.anims[anim] || Object.values(d.anims)[0];
      const n = Math.floor(t * a.fps);
      const col = a.loop ? n % a.count : Math.min(n, a.count - 1);
      return { row: a.row, col, done: !a.loop && n >= a.count };
    },

    // Tinted copy of a whole image (multiply by color, keep alpha). Cached per key+tint.
    tinted(key, tint) {
      const id = key + tint;
      if (tintCache[id]) return tintCache[id];
      const im = imgs[key];
      if (!im) return null;
      const c = document.createElement('canvas');
      c.width = im.width; c.height = im.height;
      const g = c.getContext('2d');
      g.drawImage(im, 0, 0);
      g.globalCompositeOperation = 'multiply';
      g.fillStyle = tint; g.fillRect(0, 0, c.width, c.height);
      g.globalCompositeOperation = 'destination-in';
      g.drawImage(im, 0, 0);
      tintCache[id] = c;
      return c;
    },

    // Draw an animated sprite so its anchor lands on world (x, y).
    sprite(ctx, key, anim, t, x, y, opts = {}) {
      const d = RL.ASSETS.images[key];
      const src = opts.tint ? this.tinted(key, opts.tint) : imgs[key];
      const s = S();
      if (!d) return;
      const [cw, ch] = d.cell || [d.w, d.h];
      const [ax, ay] = d.anchor || [cw / 2, ch / 2];
      const f = opts.frame || this.frameFor(key, anim, t);
      ctx.save();
      ctx.translate(x * s, y * s);
      if (opts.rot) ctx.rotate(opts.rot);
      if (opts.flip) ctx.scale(-1, 1);
      if (opts.sx || opts.sy) ctx.scale(opts.sx || 1, opts.sy || 1);
      if (opts.alpha != null) ctx.globalAlpha = opts.alpha;
      if (src) ctx.drawImage(src, f.col * cw, f.row * ch, cw, ch, -ax, -ay, cw, ch);
      else fallback(ctx, key, -ax, -ay, cw, ch, opts.tint);
      ctx.restore();
      return f;
    },

    // Draw a whole (non-sheet) image with its top-left at pixel (px, py).
    image(ctx, key, px, py, opts = {}) {
      const d = RL.ASSETS.images[key];
      const im = imgs[key];
      if (!d) return;
      ctx.save();
      if (opts.alpha != null) ctx.globalAlpha = opts.alpha;
      if (im) {
        if (opts.crop) ctx.drawImage(im, 0, 0, opts.crop[0], opts.crop[1], px, py, opts.crop[0], opts.crop[1]);
        else ctx.drawImage(im, px, py);
      } else fallback(ctx, key, px, py, opts.crop ? opts.crop[0] : d.w, d.h);
      ctx.restore();
    },
  };

  function fallback(ctx, key, x, y, w, h, tint) {
    ctx.fillStyle = tint || '#ff00ff55';
    ctx.strokeStyle = '#ff00ff';
    ctx.fillRect(x, y, w, h); ctx.strokeRect(x, y, w, h);
    ctx.fillStyle = '#fff'; ctx.font = '20px sans-serif';
    ctx.fillText(key, x + 4, y + 22);
  }
})();
