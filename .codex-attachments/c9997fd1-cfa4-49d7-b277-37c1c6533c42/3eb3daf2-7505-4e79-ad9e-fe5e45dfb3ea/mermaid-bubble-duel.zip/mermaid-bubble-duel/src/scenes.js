// Screens: title, reef map hub, shell shop, arena desk, bout, results, practice, current ride.
(function () {
  const A = () => RL.Assets;
  const W = 1200, H = 900;
  RL.UI_FONT = '"Baloo 2", "Trebuchet MS", "Segoe UI", sans-serif';

  // ---------- Save (per browser; wrapped so it never throws) ----------
  const SAVE_KEY = 'reef-of-light-bubble-duel-v1';
  const fresh = () => ({ pearls: RL.ECONOMY.startPearls, rank: RL.ECONOMY.startRank, charm: 'none', color: 'aqua',
    owned: { charms: ['none'], colors: ['aqua'] }, kind: RL.CONFIG.KIND_MODE_DEFAULT, bestRide: 0, wins: 0 });
  RL.Save = {
    data: fresh(),
    load() { try { const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if (s) this.data = Object.assign(fresh(), s); } catch (e) {} },
    write() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.data)); } catch (e) {} },
    reset() { this.data = fresh(); this.write(); },
  };
  const tintOf = id => (RL.BUBBLE_COLORS.find(c => c.id === id) || RL.BUBBLE_COLORS[0]).tint;

  // ---------- Menu helper (tap, mouse, keyboard) ----------
  class Menu {
    constructor(items, cols = 1) { this.items = items; this.sel = Math.max(0, items.findIndex(i => !i.disabled)); this.cols = cols; }
    update() {
      const I = RL.Input, n = this.items.length;
      const move = d => { for (let k = 1; k <= n; k++) { const j = (this.sel + d * k + n * 10) % n; if (!this.items[j].disabled) { this.sel = j; RL.Sfx.click(); return; } } };
      if (I.key('ArrowDown') || I.key('KeyS')) move(this.cols);
      if (I.key('ArrowUp') || I.key('KeyW')) move(-this.cols);
      if (I.key('ArrowRight') || I.key('KeyD')) move(1);
      if (I.key('ArrowLeft') || I.key('KeyA')) move(-1);
      const tap = I.tap();
      if (tap) {
        const j = this.items.findIndex(it => !it.disabled && Math.abs(tap.x - it.x) < (it.w || 480) / 2 && Math.abs(tap.y - it.y) < (it.h || 60) / 2);
        if (j >= 0) { this.sel = j; return this.fire(); }
      }
      if (I.key('Enter') || I.key('Space')) return this.fire();
    }
    fire() { const it = this.items[this.sel]; if (it && !it.disabled) { RL.Sfx.click(); it.action(); } }
    draw(ctx) {
      this.items.forEach((it, i) => {
        A().sprite(ctx, 'ui_button', i === this.sel ? 'hover' : 'normal', 0, it.x / 3, it.y / 3, { alpha: it.disabled ? 0.45 : 1 });
        RL.drawText(ctx, it.label, it.x, it.y + 11, 30, 'center');
        if (it.sub) RL.drawText(ctx, it.sub, it.x, it.y + 52, 22, 'center');
      });
    }
  }

  // ---------- Scene manager ----------
  let scene = null;
  RL.go = (s) => { scene = s; document.body.classList.toggle('playing', !!s.playing); if (s.enter) s.enter(); };
  RL.scene = () => scene;

  const topBar = (ctx) => {
    A().image(ctx, 'icon_pearl', 24, 20);
    RL.drawText(ctx, `${Math.floor(RL.Save.data.pearls)}`, 84, 58, 34);
    RL.drawText(ctx, `Rank ${Math.floor(RL.Save.data.rank)}`, W - 24, 58, 34, 'right');
  };

  // ---------- Title ----------
  RL.Title = () => ({
    t: 0,
    update() {
      this.t += 1 / 30;
      if (RL.Input.anyKey() || RL.Input.tap()) RL.go(RL.Hub());
    },
    draw(ctx) {
      A().image(ctx, 'title_bg', 0, 0);
      A().image(ctx, 'title_logo', (W - 900) / 2, 80);
      A().sprite(ctx, 'roshan', 'idle', this.t, 200, 230, { sx: 1.6, sy: 1.6 });
      A().sprite(ctx, 'bubble', 'wobble', this.t, 190, 182, { tint: tintOf(RL.Save.data.color), sx: 1.6, sy: 1.6 });
      A().sprite(ctx, 'bubble', 'wobble', this.t + 0.3, 212, 180, { tint: tintOf(RL.Save.data.color), sx: 1.6, sy: 1.6 });
      if (Math.floor(this.t * 2) % 2 === 0) RL.drawText(ctx, 'Tap or press any key', W / 2, 800, 40, 'center');
    },
  });

  // ---------- Hub: reef map ----------
  RL.HUB_SPOTS = [
    { id: 'arena', label: 'Coral Arena', x: 330, y: 330 },
    { id: 'shop', label: 'Shell Shop', x: 870, y: 330 },
    { id: 'practice', label: 'Practice Lagoon', x: 330, y: 620 },
    { id: 'ride', label: 'Current Ride', x: 870, y: 620 },
  ];
  RL.Hub = () => {
    const S = RL.Save.data;
    const items = RL.HUB_SPOTS.map(sp => ({ label: sp.label, x: sp.x, y: sp.y, action: () => {
      if (sp.id === 'arena') RL.go(RL.ArenaDesk());
      if (sp.id === 'shop') RL.go(RL.Shop());
      if (sp.id === 'practice') RL.go(RL.Bout({ mode: 'practice', stage: RL.STAGES[0] }));
      if (sp.id === 'ride') RL.go(RL.Ride());
    } }));
    items.push({ label: S.kind ? 'Gentle mode: ON' : 'Gentle mode: OFF', x: W / 2, y: 820, w: 480, action: () => { S.kind = !S.kind; RL.Save.write(); RL.go(RL.Hub()); } });
    const menu = new Menu(items, 2);
    return {
      update() { menu.update(); if (RL.Input.key('Escape')) RL.go(RL.Title()); },
      draw(ctx) { A().image(ctx, 'hub_map', 0, 0); topBar(ctx); menu.draw(ctx); },
    };
  };

  // ---------- Shell Shop ----------
  RL.Shop = () => {
    const S = RL.Save.data;
    let tab = 'charms', msg = 'Welcome, little bubble-rider! Have a look.';
    const build = () => {
      const list = tab === 'charms' ? RL.CHARMS : RL.BUBBLE_COLORS;
      const owned = tab === 'charms' ? S.owned.charms : S.owned.colors;
      const items = list.map((it, i) => {
        const have = owned.includes(it.id);
        const worn = tab === 'charms' ? S.charm === it.id : S.color === it.id;
        return {
          label: `${it.name}${worn ? '  (on)' : ''}`, sub: have ? '' : `${it.price} pearls`,
          x: 360 + (i % 2) * 520, y: 250 + Math.floor(i / 2) * 120, w: 480,
          action: () => {
            if (!have) {
              if (S.pearls < it.price) { msg = 'Not enough pearls yet. Win a bout or ride the current!'; return; }
              S.pearls -= it.price; owned.push(it.id); msg = `${it.name}: it's yours!`;
            } else msg = it.desc || `${it.name} bubbles, so pretty.`;
            if (tab === 'charms') S.charm = it.id; else S.color = it.id;
            RL.Save.write(); refresh();
          },
        };
      });
      items.push({ label: tab === 'charms' ? 'Bubble colors' : 'Charms', x: 360, y: 820, action: () => { tab = tab === 'charms' ? 'colors' : 'charms'; refresh(); } });
      items.push({ label: 'Back to the reef', x: 880, y: 820, action: () => RL.go(RL.Hub()) });
      return new Menu(items, 2);
    };
    let menu = build();
    const refresh = () => { const sel = menu.sel; menu = build(); menu.sel = Math.min(sel, menu.items.length - 1); };
    let t = 0;
    return {
      update() { t += 1 / 30; menu.update(); if (RL.Input.key('Escape')) RL.go(RL.Hub()); },
      draw(ctx) {
        A().image(ctx, 'shop_bg', 0, 0); topBar(ctx);
        A().sprite(ctx, 'shopkeeper', 'talk', t, 26, 66, { sx: 0.55, sy: 0.55 });
        const it = menu.items[menu.sel];
        if (tab === 'charms' && menu.sel < RL.CHARMS.length) {
          A().sprite(ctx, 'charm_icons', 'all', 0, 1100 / 3, 120 / 3, { frame: { row: 0, col: menu.sel } });
          RL.drawText(ctx, RL.CHARMS[menu.sel].desc, 640, 175, 26, 'center');
        }
        RL.drawText(ctx, msg, 640, 130, 28, 'center');
        menu.draw(ctx);
      },
    };
  };

  // ---------- Arena desk: mode, rival, stage ----------
  RL.ArenaDesk = (step = 'mode', pick = {}) => {
    const S = RL.Save.data;
    let items = [];
    if (step === 'mode') {
      items = [
        { label: 'Duel a reef rival', x: W / 2, y: 300, action: () => RL.go(RL.ArenaDesk('rival', { mode: 'pvc' })) },
        { label: 'Two players', sub: 'P1: A D W S    P2: arrows', x: W / 2, y: 430, action: () => RL.go(RL.ArenaDesk('stage', { mode: 'pvp' })) },
        { label: 'Back', x: W / 2, y: 600, action: () => RL.go(RL.Hub()) },
      ];
    } else if (step === 'rival') {
      items = RL.RIVALS.map((r, i) => {
        const open = r.rank <= Math.floor(S.rank) * 2 + 1;
        return { label: open ? r.name : '???', sub: open ? `Rank ${r.rank}` : `Reach rank ${Math.ceil((r.rank - 1) / 2)}`,
          disabled: !open, x: 360 + (i % 2) * 520, y: 260 + Math.floor(i / 2) * 150, action: () => RL.go(RL.ArenaDesk('stage', Object.assign(pick, { rival: r }))) };
      });
      items.push({ label: 'Back', x: W / 2, y: 720, action: () => RL.go(RL.ArenaDesk('mode')) });
    } else if (step === 'stage') {
      items = RL.STAGES.map((st, i) => ({ label: st.name, x: 360 + (i % 2) * 520, y: 260 + Math.floor(i / 2) * 150,
        action: () => RL.go(RL.Bout(Object.assign(pick, { stage: st }))) }));
      items.push({ label: 'Back', x: W / 2, y: 720, action: () => RL.go(RL.ArenaDesk(pick.mode === 'pvc' ? 'rival' : 'mode', { mode: pick.mode })) });
    }
    const menu = new Menu(items, step === 'mode' ? 1 : 2);
    const title = { mode: 'Coral Arena', rival: 'Pick a rival', stage: 'Pick a place' }[step];
    return {
      update() { menu.update(); if (RL.Input.key('Escape')) RL.go(RL.Hub()); },
      draw(ctx) { A().image(ctx, 'hub_map', 0, 0, { alpha: 0.6 }); ctx.fillStyle = 'rgba(5,25,50,0.45)'; ctx.fillRect(0, 0, W, H);
        topBar(ctx); RL.drawText(ctx, title, W / 2, 150, 64, 'center'); menu.draw(ctx); },
    };
  };

  // ---------- Bout ----------
  RL.Bout = (pick) => {
    const S = RL.Save.data;
    const hero = { name: 'Roshan', sheet: 'roshan', tint: tintOf(S.color), charm: S.charm };
    if (/[?&]demo\b/.test(location.search) && pick.mode !== 'practice') hero.cpu = { skill: 70, reflex: 70 }; // CPU plays Roshan (testing)
    let p2 = null;
    if (pick.mode === 'pvc') {
      const r = pick.rival, k = S.kind ? 0.7 : 1;
      p2 = { name: r.name.split(' ')[0], sheet: r.sheet, tint: r.bubbleTint, cpu: { skill: r.skill * k, reflex: r.reflex * k },
        charm: r.rank >= 40 ? 'wand' : 'none', maxVX: 2 + 0.04 * r.skill * 1.0 + 1.5, maxVY: 2 + 0.03 * r.skill + 1.5 };
    } else if (pick.mode === 'pvp') {
      p2 = { name: 'Friend', sheet: 'rival_coralie', tint: '#ff9fb6', charm: 'none' };
    }
    const match = new RL.Match({ mode: pick.mode, stage: pick.stage, p1: hero, p2, rival: pick.rival, kind: S.kind });
    let intro = pick.mode === 'practice' ? 0 : 60;
    return {
      match, playing: true,
      update() {
        if (RL.Input.key('Escape')) return RL.go(RL.Hub());
        if (intro > 0) { intro--; return; }
        match.step();
        if (match.result) RL.go(RL.Results(pick, match.result));
      },
      draw(ctx) {
        match.draw(ctx);
        if (intro > 0) RL.drawBanner(ctx, intro > 20 ? pick.stage.name : 'Swim!', pick.mode === 'pvc' ? `vs ${pick.rival.name}` : 'Pop bubbles from above!');
      },
    };
  };

  // ---------- Results ----------
  RL.Results = (pick, res) => {
    const S = RL.Save.data;
    let lines = [];
    if (pick.mode === 'pvc') {
      const before = S.rank;
      if (res.won) {
        S.rank += Math.max(1, 2 + (pick.rival.rank - S.rank) / 8 + res.livesDiff);
        S.wins += 1;
      } else if (!S.kind) S.rank = Math.max(1, S.rank - 1);
      const pay = res.won ? RL.ECONOMY.payBase + RL.ECONOMY.payPerRank * Math.floor(S.rank) : 3;
      S.pearls += Math.round(pay);
      RL.Save.write();
      lines = [res.won ? 'You win!' : 'So close!', `Pearls +${Math.round(pay)}`, `Rank ${Math.floor(before)} → ${Math.floor(S.rank)}`];
    } else lines = [`${res.winner.name} wins!`, '', ''];
    const menu = new Menu([
      { label: 'Again', x: 360, y: 760, action: () => RL.go(RL.Bout(pick)) },
      { label: 'Back to the reef', x: 880, y: 760, action: () => RL.go(RL.Hub()) },
    ], 2);
    let t = 0;
    const heroWon = pick.mode !== 'pvc' || res.won;
    return {
      update() { t += 1 / 30; menu.update(); },
      draw(ctx) {
        A().image(ctx, 'results_bg', 0, 0); topBar(ctx);
        A().sprite(ctx, 'roshan', heroWon ? 'cheer' : 'sad', t, 140, 200, { sx: 1.8, sy: 1.8 });
        if (pick.mode === 'pvc') A().sprite(ctx, pick.rival.sheet, heroWon ? 'sad' : 'cheer', t, 270, 200, { sx: 1.8, sy: 1.8, flip: true });
        lines.forEach((l, i) => RL.drawText(ctx, l, W / 2, 140 + i * 70, i ? 40 : 72, 'center'));
        menu.draw(ctx);
      },
    };
  };

  // ---------- Current Ride (bonus) ----------
  RL.Ride = () => {
    const S = RL.Save.data;
    const f = new RL.Fighter({ slot: 1, name: 'Roshan', sheet: 'roshan', tint: tintOf(S.color), x: 120, y: 150, lives: 0, charm: 'none' });
    const world = { drift: 0, stage: { inflation: 'normal' }, kind: S.kind, fx: [], shots: [], opponentOf: () => null };
    let jellies = [], pearls = [], scroll = 0, speed = 2, t = 0, score = 0, over = false, overT = 0, ready = 60;
    return {
      playing: true,
      update() {
        if (RL.Input.key('Escape')) return RL.go(RL.Hub());
        if (over) { if (++overT > 40 && (RL.Input.anyKey() || RL.Input.tap())) RL.go(RL.Hub()); return; }
        if (ready > 0) { ready--; f.animT += 1 / 30; scroll += 1; return; }
        t++; scroll += speed; speed = Math.min(5, 2 + t / 1800);
        f.step(RL.Input.read('solo', true), world);
        f.x = Math.max(20, Math.min(380, f.x));
        if (t % 70 === 0) { // a short line of jellies at one height
          const y = 50 + Math.random() * 200, n = 1 + Math.floor(Math.random() * 3);
          for (let i = 0; i < n; i++) jellies.push({ x: 420 + i * 22, y: y + Math.sin(i) * 8, a: Math.random() * 6 });
        }
        if (t % 25 === 0 && Math.random() < 0.7) pearls.push({ x: 420, y: 40 + Math.random() * 210, a: 0 });
        jellies.forEach(j => { j.x -= speed * 1.2; j.a += 0.1; j.y += Math.sin(j.a) * 0.6; });
        pearls.forEach(p => { p.x -= speed; p.a += 1 / 30; });
        const body = RL.boxAt(f, RL.CONFIG.BODY_BOX);
        pearls = pearls.filter(p => {
          const hit = RL.overlapWrapped(body, { x: p.x - 8, y: p.y - 8, w: 16, h: 16 }) || RL.overlapWrapped(RL.boxAt(f, RL.CONFIG.BUBBLE_BOX), { x: p.x - 8, y: p.y - 8, w: 16, h: 16 });
          if (hit) { score++; RL.Sfx.pearl(); }
          return !hit && p.x > -20;
        });
        for (const j of jellies) {
          const jb = { x: j.x - 9, y: j.y - 9, w: 18, h: 18 };
          if (f.invincible === 0 && (RL.overlapWrapped(body, jb) || RL.overlapWrapped(RL.boxAt(f, RL.CONFIG.BUBBLE_BOX), jb))) {
            if (S.kind && f.bubbles > 1) { f.pop(); f.invincible = 40; } else { over = true; }
          }
        }
        jellies = jellies.filter(j => j.x > -30);
        if (f.y > 290) {
          if (S.kind && f.bubbles > 1) { f.pop(); f.y = 285; f.vy = -9; f.invincible = 40; }
          else over = true;
        }
        world.fx.forEach(e => e.t += 1 / 30);
        if (over) { S.pearls += score; S.bestRide = Math.max(S.bestRide, score); RL.Save.write(); RL.Sfx.lose(); }
      },
      draw(ctx) {
        const im = 'bg_ride', off = (scroll * 3) % 2400;
        A().image(ctx, im, -off, 0); A().image(ctx, im, 2400 - off, 0);
        A().image(ctx, 'fg_trench', 0, 750);
        pearls.forEach(p => A().sprite(ctx, 'glow_pearl', 'shine', p.a, p.x, p.y));
        jellies.forEach(j => A().sprite(ctx, 'jelly', 'drift', j.a / 3, j.x, j.y));
        f.draw(ctx);
        A().image(ctx, 'icon_pearl', 24, 20); RL.drawText(ctx, `${score}`, 84, 58, 34);
        RL.drawText(ctx, `Best ${S.bestRide}`, W - 24, 58, 30, 'right');
        if (ready > 0) RL.drawBanner(ctx, 'Current Ride', 'Kick to stay up! Grab pearls, dodge jellies.');
        if (over) RL.drawBanner(ctx, 'Ride over!', `+${score} pearls  ·  tap to go back`);
      },
    };
  };
})();
