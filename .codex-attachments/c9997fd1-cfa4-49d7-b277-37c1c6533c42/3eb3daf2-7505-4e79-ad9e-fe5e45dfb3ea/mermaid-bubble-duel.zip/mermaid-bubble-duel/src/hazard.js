// Grumbletooth: a sleepy anglerfish who patrols the trench and gulps swimmers who dip too low.
(function () {
  class Grumbletooth {
    constructor() {
      this.t = Math.random() * 200;
      this.x = 200; this.y = RL.CONFIG.HAZARD.restY;
      this.face = 1; this.provoke = 0;
      this.state = 'swim'; this.stateT = 0; this.animT = 0;
      this.target = null;
    }
    mouthBox() { return { x: this.x + this.face * 10 - 14, y: this.y + 4, w: 28, h: 22 }; }

    step(world) {
      const H = RL.CONFIG.HAZARD;
      this.animT += 1 / 30;
      const fighters = world.fighters.filter(f => !f.lost && !f.swallowed);
      const anyLow = fighters.some(f => f.y > H.lowY);

      if (this.state === 'swim') {
        this.t += 1;
        this.x = H.patrolCenter + H.patrolRadius * Math.cos(this.t / H.period);
        this.face = Math.sin(this.t / H.period) < 0 ? 1 : -1; // moving direction
        this.provoke = anyLow ? Math.min(H.provokeMax, this.provoke + 1) : Math.max(0, this.provoke - 1);
        this.y = H.restY - (H.restY - H.riseY) * (this.provoke / H.provokeMax);
        for (const f of fighters) {
          const dx = RL.wrapDX(f.x - this.x);
          if (f.y > H.lowY && f.invincible === 0 && dx * this.face > 0 && Math.abs(dx) < H.reach) {
            this.state = 'windup'; this.stateT = 0; this.target = f; break;
          }
        }
      } else if (this.state === 'windup') {
        // telegraph: shiver in place (longer in kind mode)
        const wait = H.windup * (world.kind ? 1.6 : 1);
        if (++this.stateT >= wait) { this.state = 'lunge'; this.stateT = 0; this.animT = 0; }
      } else if (this.state === 'lunge') {
        this.stateT++;
        const k = this.stateT / H.lungeFrames;
        this.y = H.riseY - (H.riseY - H.lungeY) * Math.sin(Math.min(1, k) * Math.PI);
        this.x += this.face * 1.5;
        const mb = this.mouthBox();
        for (const f of fighters) {
          if (f.invincible === 0 && RL.overlapWrapped(mb, RL.boxAt(f, RL.CONFIG.BODY_BOX))) {
            f.swallowed = true; f.vx = f.vy = 0; this.state = 'gulp'; this.stateT = 0; this.target = f;
            RL.Sfx.gulp(); break;
          }
        }
        if (this.state === 'lunge' && this.stateT >= H.lungeFrames) { this.state = 'swim'; this.target = null; }
      } else if (this.state === 'gulp') {
        if (++this.stateT >= 30) {
          const f = this.target;
          if (f) { f.swallowed = false; f.loseLife(world); }
          this.state = 'swim'; this.target = null;
        }
      }
    }

    draw(ctx) {
      const anim = this.state === 'lunge' ? 'lunge' : this.state === 'gulp' ? 'gulp' : 'swim';
      const shiver = this.state === 'windup' ? Math.sin(this.stateT * 2) * 1.2 : 0;
      RL.Assets.sprite(ctx, 'grumbletooth', anim, this.animT, this.x + shiver, this.y, { flip: this.face < 0 });
    }
  }
  RL.Grumbletooth = Grumbletooth;
})();
