// Asset manifest. The game reads ONLY this file to find art.
// Replace any PNG in place, keeping its file name, pixel size, cell grid and anchor,
// and the game picks it up with no code changes. See docs/CODEX_ART_HANDOFF.md.
//
// Units: pixels at 3x logical scale (1 world unit = 3 px).
// Sheets: cells are laid out in rows; each animation is one row, frames left to right.
// anchor: the pixel inside a cell that sits on the object's world position.
window.RL = window.RL || {};

(function () {
  const charAnims = {
    idle:   { row: 0, count: 4, fps: 6,  loop: true  },  // treading water, tail sway
    kick:   { row: 1, count: 4, fps: 18, loop: false },  // one strong tail flick (the "flap")
    tumble: { row: 2, count: 4, fps: 10, loop: true  },  // no bubbles left, sinking
    hurt:   { row: 3, count: 2, fps: 8,  loop: false },  // just lost a bubble
    cheer:  { row: 4, count: 4, fps: 8,  loop: true  },  // results screen, won
    sad:    { row: 5, count: 2, fps: 3,  loop: true  },  // results screen, lost
  };
  const character = (file, notes) => ({
    file, w: 384, h: 768, cell: [96, 128], anchor: [48, 74], anims: charAnims, notes,
  });

  RL.ASSETS = {
    base: 'assets/',
    images: {
      // ---- Characters (body only; bubbles are a separate layer) ----
      roshan:        character('sprites/roshan.png',        'Hero. Mermaid Roshan. Faces right; game mirrors for left.'),
      rival_tidbit:  character('sprites/rival_tidbit.png',  'Rival 1, easiest. Seahorse kid.'),
      rival_marlo:   character('sprites/rival_marlo.png',   'Rival 2. Otter.'),
      rival_inkwell: character('sprites/rival_inkwell.png', 'Rival 3. Octopus.'),
      rival_coralie: character('sprites/rival_coralie.png', 'Rival 4, hardest. Mermaid.'),

      // ---- Bubbles (neutral white/pale, tinted at runtime) ----
      bubble: { file: 'sprites/bubble.png', w: 288, h: 168, cell: [72, 84], anchor: [36, 78],
        anims: { wobble: { row: 0, count: 4, fps: 5, loop: true }, pop: { row: 1, count: 4, fps: 20, loop: false } },
        notes: 'One bubble. Drawn twice per fighter. Anchor = where the tether meets the bubble.' },
      tether: { file: 'sprites/tether.png', w: 12, h: 60, cell: [12, 60], anchor: [6, 60],
        anims: { still: { row: 0, count: 1, fps: 1, loop: true } },
        notes: 'Kelp string from waist to bubble. Stretched vertically by the game.' },

      // ---- Hazard ----
      grumbletooth: { file: 'sprites/grumbletooth.png', w: 960, h: 540, cell: [240, 180], anchor: [120, 60],
        anims: { swim: { row: 0, count: 4, fps: 6, loop: true }, lunge: { row: 1, count: 4, fps: 12, loop: false },
                 gulp: { row: 2, count: 2, fps: 6, loop: true } },
        notes: 'Sleepy trench anglerfish. Faces right. Anchor = top of mouth. Must read as grumpy-silly, never scary.' },

      // ---- Effects ----
      fx_pop:     { file: 'fx/pop.png',     w: 384, h: 96,  cell: [96, 96],  anchor: [48, 48], anims: { play: { row: 0, count: 4, fps: 20, loop: false } }, notes: 'Bubble pop burst.' },
      fx_splash:  { file: 'fx/splash.png',  w: 384, h: 96,  cell: [96, 96],  anchor: [48, 80], anims: { play: { row: 0, count: 4, fps: 16, loop: false } }, notes: 'Bonk on the water surface.' },
      fx_sparkle: { file: 'fx/sparkle.png', w: 192, h: 48,  cell: [48, 48],  anchor: [24, 24], anims: { play: { row: 0, count: 4, fps: 16, loop: true } },  notes: 'Sparkle Wand shot.' },
      fx_ink:     { file: 'fx/ink.png',     w: 576, h: 144, cell: [144,144], anchor: [72, 72], anims: { play: { row: 0, count: 4, fps: 8,  loop: true } },  notes: 'Ink Puff cloud around a held rival.' },
      fx_respawn: { file: 'fx/respawn.png', w: 384, h: 96,  cell: [96, 96],  anchor: [48, 48], anims: { play: { row: 0, count: 4, fps: 12, loop: false } }, notes: 'Bubble column when relaunching from the trench.' },

      // ---- Current Ride (bonus mode) ----
      jelly:       { file: 'sprites/jelly.png',  w: 192, h: 48, cell: [48, 48], anchor: [24, 24], anims: { drift: { row: 0, count: 4, fps: 8, loop: true } }, notes: 'Zappy jellyfish. Touch = out.' },
      glow_pearl:  { file: 'sprites/pearl.png',  w: 144, h: 36, cell: [36, 36], anchor: [18, 18], anims: { shine: { row: 0, count: 4, fps: 8, loop: true } }, notes: 'Pickup. Also the currency icon.' },

      // ---- Backgrounds (full playfield, 400x300 logical) ----
      bg_sunlit: { file: 'bg/sunlit.png', w: 1200, h: 900, notes: 'Bright shallow reef, god rays.' },
      bg_vents:  { file: 'bg/vents.png',  w: 1200, h: 900, notes: 'Warm orange vents, rising shimmer.' },
      bg_kelp:   { file: 'bg/kelp.png',   w: 1200, h: 900, notes: 'Cool blue-green kelp forest.' },
      bg_deep:   { file: 'bg/deep.png',   w: 1200, h: 900, notes: 'Dark water, bioluminescent dots.' },
      bg_ride:   { file: 'bg/ride.png',   w: 2400, h: 900, notes: 'Current Ride. Tiles horizontally: left and right edges must match.' },
      fg_trench: { file: 'bg/trench.png', w: 1200, h: 150, notes: 'Dark trench lip drawn over the bottom of every arena at world y 250..300. Top edge fades to transparent; Grumbletooth hides behind it.' },

      // ---- Screens ----
      title_logo:  { file: 'ui/title_logo.png',  w: 900,  h: 360, notes: 'Title wordmark: "Reef of Light: Bubble Duel".' },
      title_bg:    { file: 'ui/title_bg.png',    w: 1200, h: 900, notes: 'Title screen backdrop (full canvas).' },
      hub_map:     { file: 'ui/hub_map.png',     w: 1200, h: 900, notes: 'Reef map hub. Hotspots are defined in src/scenes.js (HUB_SPOTS).' },
      shop_bg:     { file: 'ui/shop_bg.png',     w: 1200, h: 900, notes: 'Shell Shop interior.' },
      results_bg:  { file: 'ui/results_bg.png',  w: 1200, h: 900, notes: 'Results screen.' },
      shopkeeper:  { file: 'sprites/shopkeeper.png', w: 480, h: 240, cell: [240, 240], anchor: [120, 240],
        anims: { talk: { row: 0, count: 2, fps: 4, loop: true } }, notes: 'Shell Shop host, a hermit crab. 2-frame talk loop.' },

      // ---- UI pieces ----
      ui_button:     { file: 'ui/button.png',      w: 480, h: 120, cell: [480, 60], anchor: [240, 30],
        anims: { normal: { row: 0, count: 1, fps: 1, loop: true }, hover: { row: 1, count: 1, fps: 1, loop: true } },
        notes: '9-slice not required: game draws at native size, text on top.' },
      hud_glow_frame:{ file: 'ui/glow_frame.png',  w: 330, h: 60, notes: 'Energy ("glow") meter frame. Inner fill area: x 12..318, y 18..42.' },
      hud_glow_fill: { file: 'ui/glow_fill.png',   w: 306, h: 24, notes: 'Meter fill, cropped from the left by the game.' },
      hud_ready:     { file: 'ui/ready.png',       w: 96,  h: 48, cell: [48, 48], anchor: [24, 24],
        anims: { off: { row: 0, count: 1, fps: 1, loop: true }, on: { row: 0, count: 2, fps: 4, loop: true } }, notes: 'Charm-ready light. Frame 0 off, frame 1 on.' },
      hud_spare:     { file: 'ui/spare.png',       w: 30,  h: 36, notes: 'Small spare-life bubble icon.' },
      icon_pearl:    { file: 'ui/icon_pearl.png',  w: 48,  h: 48, notes: 'Currency icon.' },
      charm_icons:   { file: 'ui/charms.png',      w: 768, h: 96, cell: [96, 96], anchor: [48, 48],
        anims: { all: { row: 0, count: 8, fps: 1, loop: false } },
        notes: 'One icon per charm in RL.CHARMS order: none, finmotor, pearl, conch, wand, lasso, hush, ink.' },
    },
  };
})();
